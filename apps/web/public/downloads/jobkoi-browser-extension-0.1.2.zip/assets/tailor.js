import{c as ve,r as S,j as n,C as re,R as q,X as Je,T as we,B as _t,a as Bt,F as je,b as Ht,d as Jt}from"./jobkoi-theme-BJRYeKxG.js";import{b as Ke,p as pt,n as ut,T as ht,S as ie,K as Kt,W as $e,E as le,D as ke,_ as Ut,U as qt}from"./preload-helper-BY6cmiid.js";import{E as Wt,c as Gt,J as Xt,I as Vt,a3 as Yt,l as Ue,a as qe,a4 as We,a5 as Ge,a6 as Xe,a7 as Ve,a8 as Zt,a9 as Qt,aa as en,ab as tn}from"./storage-DoBTTLH_.js";import{extractResumePdfLayout as Ye}from"./resumeParser-CCqCcXMa.js";import{A as Se}from"./arrow-right-YoIHuNbj.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const nn=ve("ChevronUp",[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const an=ve("FolderOpen",[["path",{d:"m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2",key:"usdka0"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const sn=ve("ListChecks",[["path",{d:"m3 17 2 2 4-4",key:"1jhpwq"}],["path",{d:"m3 7 2 2 4-4",key:"1obspn"}],["path",{d:"M13 6h8",key:"15sg57"}],["path",{d:"M13 12h8",key:"h98zly"}],["path",{d:"M13 18h8",key:"oe0vm4"}]]),mt=(e,t=0)=>{if(!e.length)return t;const a=[...e].sort((o,r)=>o-r),s=Math.floor(a.length/2);return a.length%2?a[s]:(a[s-1]+a[s])/2},Ee=e=>e.x+e.width;function on(e){return[...e].sort((t,a)=>{const s=[...t.text.trim()].length*Math.max(1,t.width);return[...a.text.trim()].length*Math.max(1,a.width)-s})[0]||e[0]}function rn(e){const t=[];return[...e].filter(a=>a.text.trim()&&Math.abs(a.rotation||0)<2).sort((a,s)=>a.top-s.top||a.x-s.x).forEach(a=>{const s=a.top+a.height/2,o=[...t].reverse().find(r=>{const i=r.top+r.height/2,p=Math.max(1.25,Math.min(r.height,a.height)*.24);return Math.abs(i-s)<=p});if(o){o.items.push(a);const r=Math.max(o.top+o.height,a.top+a.height);o.top=Math.min(o.top,a.top),o.height=r-o.top}else t.push({items:[a],top:a.top,height:a.height})}),t.sort((a,s)=>a.top-s.top)}function ln(e,t){if(!e)return"";const a=t.x-Ee(e),s=Math.max(2.8,Math.min(e.fontSize,t.fontSize)*.48);return a<=s*.65?"":" ".repeat(Math.max(1,Math.min(8,Math.round(a/s))))}function dn(e){const t=[...e].sort((c,l)=>c.x-l.x),a=on(t);let s;const o=t.map(c=>{const l=`${ln(s,c)}${c.text}`;return s=c,l}).join(""),r=Math.min(...t.map(c=>c.x)),i=Math.min(...t.map(c=>c.top)),p=Math.max(...t.map(Ee)),h=Math.max(...t.map(c=>c.top+c.height));return{items:t,text:o,x:r,top:i,width:p-r,height:h-i,fontSize:a.fontSize,fontFamily:a.fontFamily,fontId:a.fontId,fallbackFontFamily:a.fallbackFontFamily,fontWeight:a.fontWeight,fontStyle:a.fontStyle,color:a.color,rotation:a.rotation,direction:a.direction}}function cn(e){const t=[...e.items].sort((s,o)=>s.x-o.x),a=[];return t.forEach(s=>{const o=a.at(-1),r=o==null?void 0:o.at(-1);if(!o||!r){a.push([s]);return}const i=s.x-Ee(r),p=Math.max(r.fontSize,s.fontSize),h=i>Math.max(18,p*1.65),c=i>p*.72&&(Math.abs(r.fontSize-s.fontSize)>1.35||r.fontWeight!==s.fontWeight);h||c?a.push([s]):o.push(s)}),a.map(dn)}function pn(e,t){return Math.abs(e.fontSize-t.fontSize)<=1.25&&e.fontWeight===t.fontWeight&&e.fontStyle===t.fontStyle&&Math.abs(e.rotation-t.rotation)<1}function un(e,t){return Math.abs(e.x-t.x)<=Math.max(e.fontSize,t.fontSize)*2.8}function hn(e,t){return{id:`pdf-block-${t}`,itemIds:e.items.map(a=>a.id),text:e.text,x:e.x,top:e.top,width:e.width,height:e.height,lineHeight:Math.max(e.height,e.fontSize*1.16),lastLineTop:e.top,lastLineWidth:e.width,textIndent:0,fontSize:e.fontSize,fontFamily:e.fontFamily,fontId:e.fontId,fallbackFontFamily:e.fallbackFontFamily,fontWeight:e.fontWeight,fontStyle:e.fontStyle,color:e.color,rotation:e.rotation,direction:e.direction}}function mn(e){const t=rn(e.items).flatMap(cn).sort((s,o)=>s.top-o.top||s.x-o.x),a=[];return t.forEach((s,o)=>{const r=[...a].reverse().find(x=>{const y=s.top-(x.top+x.height),j=Math.max(x.width,s.width)>=e.widthPt*.25,N=x.lastLineWidth<x.width*.45&&s.width>x.width*.55&&Math.abs(x.x-s.x)<=Math.max(x.fontSize,s.fontSize);return y>=-1.5&&y<=Math.max(x.fontSize,s.fontSize)*.88&&j&&!N&&pn(x,s)&&un(x,s)});if(!r){a.push(hn(s,o));return}const i=r.top,p=r.text,h=r.x+r.width,c=s.x+s.width,l=s.top-r.lastLineTop,m=r.x+r.textIndent,u=Math.min(r.x,s.x);r.textIndent=m-u,r.text=`${p}
${s.text}`,r.itemIds.push(...s.items.map(x=>x.id)),r.x=u,r.width=Math.max(h,c)-u,r.height=Math.max(r.height,s.top+s.height-i),r.lineHeight=mt([r.lineHeight,l],r.lineHeight),r.lastLineTop=s.top,r.lastLineWidth=s.width}),a}function fn(e,t,a){const s=[...e.text.replace(/\s+/g,"")].length,o=e.fontSize>=t*1.2,r=e.fontWeight===700&&e.fontSize>=t*.98&&e.width<a*.42&&s<=16;return s>0&&s<=28&&(o||r)}function Pe(e){const t=mn(e);if(!t.length)return[];const a=mt(t.flatMap(r=>Array(Math.max(1,[...r.text].length)).fill(r.fontSize)),10),s=t.filter(r=>fn(r,a,e.widthPt)).map(r=>Math.max(0,r.top-Math.max(3,r.fontSize*.48))).sort((r,i)=>r-i).filter((r,i,p)=>i===0||r-p[i-1]>a*1.5);(!s.length||s[0]>a)&&s.unshift(0);const o=[...s,e.heightPt];return s.map((r,i)=>{const p=o[i+1];return{id:`pdf-region-${e.page}-${i}`,top:r,height:Math.max(1,p-r),blocks:t.filter(h=>h.top>=r&&h.top<p)}}).filter(r=>r.blocks.length)}const gn=24,xn=16;function bn(e){return e?e.pages.flatMap(t=>Pe(t).flatMap(a=>a.blocks.map(s=>({blockId:s.id,page:t.page,text:s.text.trim()})))).filter(t=>[...U(t.text)].length>=gn).sort((t,a)=>[...a.text].length-[...t.text].length).slice(0,xn):[]}function Ze(e,t){if(!Array.isArray(e)||t.length===0)return[];const a=new Map(t.map(o=>[`${o.page}:${o.blockId}`,o])),s=new Set;return e.flatMap(o=>{if(!o||typeof o!="object")return[];const r=o,i=String(r.block_id||r.blockId||"").trim(),p=Number(r.page||1),h=String(r.source_text||r.sourceText||"").trim(),c=String(r.tailored_text||r.tailoredText||"").trim(),l=`${p}:${i}`,m=a.get(l);if(!m||s.has(l)||!h||!c)return[];if(U(m.text)!==U(h)||U(h)===U(c))return[];if(!ft(h,c))return[];s.add(l);const u=Array.isArray(r.map_ids)?r.map_ids.map(String).filter(Boolean):[];return[{blockId:i,page:p,sourceText:m.text,tailoredText:c,mapIds:u}]})}function ft(e,t){const a=[...U(e)].length,s=[...U(t)].length,o=Qe(e),r=Qe(t);return!a||!s||!o||!r?!1:s>=a*.9&&s<=a*1.1&&r>=o*.88&&r<=o*1.08}function U(e){return String(e||"").replace(/\s+/g,"").trim()}function Qe(e){return[...String(e||"")].reduce((t,a)=>/\s/.test(a)?t+.28:/[\u0000-\u00ff]/.test(a)?/[A-Z0-9]/.test(a)?t+.62:/[.,:;!?'"()\-_/\\]/.test(a)?t+.36:t+.54:/[，。；：！？、（）《》【】“”‘’]/.test(a)?t+.82:t+1,0)}const yn=96/72,z=e=>e.replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]||t);function vn({layout:e,resume:t,sourceProfile:a,jd:s,pdfPatches:o=[]}){var D;if(!e.pages.length)throw new Error("原 PDF 没有可用页面，请重新导入正确的 PDF 母版");const r=e.characterCount??e.pages.reduce(($,k)=>$+k.items.reduce((P,E)=>P+[...E.text.trim()].length,0),0),i=jn(e),p=Cn(t,s),h=Dn(e,t,a,p,o),c=new Map(h.map($=>[$.item.id,$])),l=new Map(e.fonts.map($=>[$.id,$])),m=new Map;e.pages.forEach($=>$.items.forEach(k=>{const P=m.get(k.fontId)||new Set;[...k.text].forEach(E=>P.add(E)),m.set(k.fontId,P)}));let u=0,x=0;const y=e.pages.map($=>{const k=Pe($);return x+=k.length,u+=k.reduce((P,E)=>P+E.blocks.length,0),`<section class="source-page" data-page="${$.page}" style="width:${C($.widthPt)}px;height:${C($.heightPt)}px">
      ${kn($)}
      <img src="${z($.imageDataUrl)}" alt="原 PDF 第 ${$.page} 页的文字与图片" class="source-page-image">
      ${k.map(P=>Nn(P,$,c,l,m)).join("")}
    </section>`}).join(""),j=e.pages[0],N=(j==null?void 0:j.widthPt)||595,F=(j==null?void 0:j.heightPt)||842,g=r===0?"原 PDF 页面已完整保留；当前未提取到可编辑文字，仍可预览与保存。":h.length?`已从原 PDF 恢复 ${r} 个可编辑字符，并定制替换 ${h.length} 处内容。`:`已从原 PDF 恢复 ${r} 个可编辑字符；版式与图像按原坐标保留。`;return`<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="generator" content="offerflow-pdf-backed-tailor">
  <meta name="source-layout" content="pdf">
  <meta name="source-fingerprint" content="${i}">
  <meta name="source-character-count" content="${r}">
  <meta name="source-text-item-count" content="${e.pages.reduce(($,k)=>$+k.items.length,0)}">
  <meta name="source-font-count" content="${((D=e.fonts)==null?void 0:D.length)||0}">
  <meta name="source-vector-shape-count" content="${e.pages.reduce(($,k)=>{var P;return $+(((P=k.vectorShapes)==null?void 0:P.length)||0)},0)}">
  <meta name="tailored-override-count" content="${h.length}">
  <meta name="editable-block-count" content="${u}">
  <meta name="editable-region-count" content="${x}">
  <title>${z(t.targetCompany||"")}-${z(t.header.name||"定制简历")}</title>
  <style>${wn(e.fonts||[])}${Sn(N,F)}</style>
</head>
<body>
  <header class="toolbar">
    <strong>原 PDF 转 HTML</strong>
    <span id="editor-status">${z(g)}</span>
    <div class="toolbar-actions">
      <button id="tailor-edit-toggle" type="button" disabled>开始编辑</button>
      <button id="tailor-reset" type="button">恢复原版</button>
      <button id="tailor-save-html" type="button">保存 HTML</button>
      <button id="tailor-print" type="button">保存为 PDF</button>
    </div>
  </header>
  <main class="document">${y}</main>
  <script>${Tn()}<\/script>
</body>
</html>`}function wn(e){return e.map(t=>{const a=t.mimeType.includes("woff2")?"woff2":t.mimeType.includes("woff")?"woff":"opentype";return`@font-face{font-family:${JSON.stringify(t.family)};src:url(data:${t.mimeType};base64,${t.dataBase64}) format("${a}");font-weight:${t.fontWeight};font-style:${t.fontStyle};font-display:block;}`}).join("")}function O(e){return Number.isFinite(e)?String(Math.round(e*1e3)/1e3):"0"}function jn(e){const t=e.pages.map(s=>[s.page,s.widthPt,s.heightPt,s.imageDataUrl.length,s.imageDataUrl.slice(-96),s.items.map(o=>`${o.id}:${o.text}:${o.x.toFixed(2)}:${o.top.toFixed(2)}`).join("|")].join("~")).join("||");let a=2166136261;for(let s=0;s<t.length;s+=1)a^=t.charCodeAt(s),a=Math.imul(a,16777619);return(a>>>0).toString(36)}function $n(e){const t=e.dashArray.length?` stroke-dasharray="${e.dashArray.map(O).join(" ")}" stroke-dashoffset="${O(e.dashOffset)}"`:"";return`<path d="${z(e.d)}" fill="${z(e.fill)}" fill-rule="${e.fillRule}" fill-opacity="${O(e.fillOpacity)}" stroke="${z(e.stroke)}" stroke-opacity="${O(e.strokeOpacity)}" stroke-width="${O(e.strokeWidth)}" stroke-linecap="${e.lineCap}" stroke-linejoin="${e.lineJoin}" stroke-miterlimit="${O(e.miterLimit)}"${t}/>`}function kn(e){const t=e.vectorShapes||[];return t.length?`<svg class="source-page-vectors" viewBox="0 0 ${O(e.widthPt)} ${O(e.heightPt)}" preserveAspectRatio="none" aria-hidden="true">${t.map($n).join("")}</svg>`:""}function Sn(e,t){return`
    @page { size: ${e}pt ${t}pt; margin: 0; }
    :root { --sheet-width: ${C(e)}px; --sheet-height: ${C(t)}px; }
    * { box-sizing: border-box; }
    html, body { margin: 0; min-height: 100%; }
    body { background: #edf0f2; color: #172019; font-family: Arial, "PingFang SC", "Microsoft YaHei", sans-serif; }
    .toolbar { position: sticky; top: 0; z-index: 10; display: flex; align-items: center; gap: 14px; min-height: 58px; padding: 10px 18px; background: #fff; border-bottom: 1px solid #dfe5e1; box-shadow: 0 2px 10px rgba(24, 38, 29, .06); }
    .toolbar strong { white-space: nowrap; font-size: 15px; }
    #editor-status { flex: 1; min-width: 0; color: #657168; font-size: 12px; }
    .toolbar-actions { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 6px; }
    .toolbar button { border: 1px solid #d2dbd5; border-radius: 8px; padding: 7px 10px; background: #fff; color: #24312a; cursor: pointer; font-size: 12px; }
    .toolbar button:hover { border-color: #748b7b; background: #f3f7f4; }
    .toolbar button:disabled { cursor: wait; opacity: .55; }
    .document { display: flex; flex-direction: column; align-items: center; gap: 20px; padding: 24px; }
    .source-page { position: relative; flex: none; overflow: hidden; background: #fff; box-shadow: 0 12px 34px rgba(25, 35, 29, .12); page-break-after: always; }
    .source-page-vectors { position: absolute; inset: 0; display: block; width: 100%; height: 100%; z-index: 1; overflow: visible; pointer-events: none; }
    .source-page-image { position: absolute; inset: 0; display: block; width: 100%; height: 100%; z-index: 2; user-select: none; pointer-events: none; }
    .edit-region { position: absolute; left: 0; z-index: 3; width: 100%; overflow: visible; pointer-events: none; }
    .source-eraser { position: absolute; z-index: 1; display: none; pointer-events: none; transform: rotate(var(--text-rotation, 0deg)); transform-origin: 0 0; }
    .source-overlay { position: absolute; z-index: 2; display: block; min-width: 1px; padding: 0; border: 0; margin: 0; overflow: visible; white-space: pre-wrap; overflow-wrap: anywhere; color: transparent; letter-spacing: 0; outline: none; transform: translateY(var(--flow-shift, 0px)) rotate(var(--text-rotation, 0deg)); transform-origin: 0 0; }
    .source-overlay > * { font: inherit; color: inherit; letter-spacing: inherit; }
    .source-eraser[data-repainted="true"] { display: block; }
    .source-overlay[data-repainted="true"] { color: var(--text-color, #111); }
    body.editing .edit-region { pointer-events: auto; }
    body.editing .source-overlay { pointer-events: auto; cursor: text; }
    body.editing .source-overlay:hover { box-shadow: 0 0 0 1px rgba(194, 150, 0, .46); }
    body.editing .source-overlay:focus { box-shadow: 0 0 0 2px rgba(196, 147, 0, .72); background: rgba(255, 249, 224, .16); }
    .source-overlay[data-active="true"] { box-shadow: 0 0 0 2px rgba(196, 147, 0, .62); }
    .source-overlay.uses-fallback-font { font-family: var(--fallback-font), sans-serif !important; }
    body.editing .edit-region[data-overflow="true"], .edit-region.is-modified[data-overflow="true"] { box-shadow: inset 0 -3px 0 #d14b3f; }
    @media print {
      body { background: #fff; }
      .toolbar { display: none; }
      .document { padding: 0; gap: 0; }
      .source-page { box-shadow: none; }
    }
    @media (max-width: 760px) {
      .toolbar { align-items: flex-start; flex-wrap: wrap; }
      #editor-status { flex-basis: 100%; order: 3; }
      .document { align-items: flex-start; overflow-x: auto; padding: 12px; }
    }
  `}function et(e,t){return[e,t].filter(Boolean).map(a=>`'${String(a).replace(/\\/g,"\\\\").replace(/'/g,"\\'")}'`).concat("sans-serif").join(",")}function En(e,t,a){var r;let s=e.text;const o=e.itemIds.map(i=>a.get(i)).filter(i=>!!i);return o.forEach(i=>{s=i.text}),{text:s,key:((r=o[0])==null?void 0:r.key)||`source.${t.page}.${e.id}`,mapIds:[...new Set(o.flatMap(i=>i.mapIds.split(/\s+/)).filter(Boolean))].join(" "),initialOverride:o.length>0}}function Pn(e,t,a,s,o,r){const i=En(e,a,s),p=e.direction==="rtl"?"rtl":"ltr",h=o.get(e.fontId),c=[...r.get(e.fontId)||[]].join(""),l=e.fallbackFontFamily||(h==null?void 0:h.fallbackFamily)||"sans-serif",m=i.initialOverride?"true":"false",u=new Map(a.items.map(y=>[y.id,y]));return`${e.itemIds.map(y=>u.get(y)).filter(y=>!!y).map(y=>{const j=Math.min(.6,Math.max(.18,y.fontSize*.035)),N=Math.min(.45,Math.max(.12,y.fontSize*.025));return`<i class="source-eraser" aria-hidden="true" data-eraser-for="${z(e.id)}" data-repainted="${m}" style="left:${C(Math.max(0,y.x-j))}px;top:${C(Math.max(0,y.top-t.top-N))}px;width:${C(y.width+j*2)}px;height:${C(y.height+N*2)}px;background:${z(y.backgroundColor||"#ffffff")};--text-rotation:${O(y.rotation||0)}deg"></i>`}).join("")}<div class="source-overlay source-text" data-block-id="${z(e.id)}" data-edit-key="${z(i.key)}" data-map-ids="${z(i.mapIds)}" data-initial-override="${i.initialOverride?"true":"false"}" data-repainted="${m}" data-font-subset="${h!=null&&h.isSubset?"true":"false"}" data-source-glyphs="${z(c)}" data-base-top="${C(e.top-t.top)}" data-base-height="${C(e.height)}" data-base-x="${C(e.x)}" data-base-width="${C(e.width)}" dir="${p}" style="left:${C(e.x)}px;top:${C(e.top-t.top)}px;width:${C(Math.max(e.width,e.fontSize*1.5))}px;min-height:${C(Math.max(e.height,e.lineHeight))}px;font-family:${et(e.fontFamily,l)};font-size:${C(e.fontSize)}px;font-weight:${e.fontWeight};font-style:${e.fontStyle};line-height:${C(e.lineHeight)}px;text-indent:${C(Math.max(0,e.textIndent))}px;--fallback-font:${et(l,"")};--text-color:${z(e.color||"#111111")};--text-rotation:${O(e.rotation||0)}deg">${z(i.text)}</div>`}function Nn(e,t,a,s,o){const r=e.blocks.some(i=>i.itemIds.some(p=>a.has(p)));return`<section class="edit-region${r?" is-modified":""}" data-region-id="${z(e.id)}" data-initial-override="${r?"true":"false"}" style="top:${C(e.top)}px;height:${C(e.height)}px">${e.blocks.map(i=>Pn(i,e,t,a,s,o)).join("")}</section>`}function Dn(e,t,a,s,o){const r=new Map(e.pages.flatMap(l=>l.items).map(l=>[l.id,l])),i=e.pages.flatMap(l=>Pe(l).flatMap(m=>m.blocks.map(u=>({page:l.page,block:u})))),p=new Map;let h=0;const c=(l,m,u,x="")=>{const y=String(l||"").trim(),j=String(m||"").trim();if(!y||!j||y===j)return;const N=[...y].length,F=[...j].length;if(F<N*.65||F>N*1.35)return;const g=_(y),D=i.filter(B=>_(B.block.text).includes(g)).sort((B,pe)=>_(B.block.text).length-_(pe.block.text).length)[0];if(!D)return;const $=D.block,k=r.get($.itemIds[0]);if(!k)return;const P=p.get(k.id)||{item:k,text:$.text,key:`${u}.${h++}`,mapIds:x},E=Mn(P.text,y,j);E!==P.text&&(P.text=E,P.mapIds=[P.mapIds,x].filter(Boolean).join(" "),p.set(k.id,P))};return o.forEach((l,m)=>{const u=i.find(y=>y.page===l.page&&y.block.id===l.blockId);if(!u||_(u.block.text)!==_(l.sourceText))return;const x=r.get(u.block.itemIds[0]);!x||_(l.tailoredText)===_(u.block.text)||!ft(u.block.text,l.tailoredText)||p.set(x.id,{item:x,text:l.tailoredText,key:`pdfPatch.${l.page}.${l.blockId}.${m}`,mapIds:l.mapIds.join(" ")})}),c(a.fullName,t.header.name,"header.name"),c(a.email,t.header.email,"header.email"),c(a.phone,t.header.phone,"header.phone"),c(a.currentCity,t.header.city,"header.city"),c(a.targetRole,t.targetRole||t.header.headline,"header.headline"),a.education.forEach((l,m)=>{const u=t.education[m];u&&(c(l.school,u.school,`education.${m}.school`),c(l.major,u.major,`education.${m}.major`),c(l.degree,u.degree,`education.${m}.degree`),c(l.startDate,u.start,`education.${m}.start`),c(l.endDate,u.end,`education.${m}.end`))}),a.experiences.forEach((l,m)=>{const u=t.experience[m];if(!u)return;const x=s.get(u.id)||"";c(l.organization,u.company,`experience.${m}.company`,x),c(l.title,u.title,`experience.${m}.title`,x),oe(l.description,u.bullets,`experience.${m}.description`,x,c),oe(l.achievements,u.bullets,`experience.${m}.achievements`,x,c)}),a.projects.forEach((l,m)=>{const u=t.projects[m];if(!u)return;const x=s.get(u.id)||"";c(l.name,u.name,`project.${m}.name`,x),c(l.role,u.role,`project.${m}.role`,x),oe(l.description,[u.summary,...u.bullets],`project.${m}.description`,x,c),oe(l.achievement,u.bullets,`project.${m}.achievement`,x,c)}),a.campusExperiences.forEach((l,m)=>{const u=t.campus[m];u&&(c(l.type,u.type,`campus.${m}.type`),c(l.role,u.role,`campus.${m}.role`),c(l.description,u.description,`campus.${m}.description`))}),a.awards.forEach((l,m)=>{const u=t.awards[m];u&&(c(l.name,u.name,`award.${m}.name`),c(l.level,u.level,`award.${m}.level`))}),[...p.values()]}function _(e){return e.replace(/\s+/g,"").trim()}function Mn(e,t,a){if(e.includes(t))return e.replace(t,a);const s=_(t);if(!s)return e;const o=[],r=[];Array.from(e).forEach((c,l)=>{/\s/.test(c)||(o.push(c),r.push(l))});const i=o.join("").indexOf(s);if(i<0)return e;const p=r[i],h=r[i+[...s].length-1];return p===void 0||h===void 0?e:`${e.slice(0,p)}${a}${e.slice(h+1)}`}function oe(e,t,a,s,o){String(e||"").split(new RegExp("\\r?\\n|[；;]|(?<=[。.!！?？])\\s+")).map(i=>i.trim()).filter(Boolean).forEach((i,p)=>o(i,t[p],`${a}.${p}`,s))}function Cn(e,t){const a=new Map;if(!t)return a;const s=new Set([...e.education.map(o=>o.id),...e.experience.map(o=>o.id),...e.projects.map(o=>o.id),...e.campus.map(o=>o.id),...e.awards.map(o=>o.id)]);return t.mappings.forEach(o=>o.resume_ids.forEach(r=>{const i=r.split(".")[0];s.has(i)&&a.set(i,`${a.get(i)||""} ${o.map_id}`.trim())})),a}function C(e){return Math.max(0,e*yn).toFixed(2)}function Tn(){return`(() => {
    const nodes = [...document.querySelectorAll('[data-edit-key]')];
    const regions = [...document.querySelectorAll('.edit-region')];
    const erasers = [...document.querySelectorAll('[data-eraser-for]')];
    const erasersByBlock = new Map();
    erasers.forEach((eraser) => {
      const blockId = eraser.dataset.eraserFor || '';
      const values = erasersByBlock.get(blockId) || [];
      values.push(eraser);
      erasersByBlock.set(blockId, values);
    });
    const signature = document.querySelector('meta[name="source-fingerprint"]')?.content || 'unknown';
    const key = 'offerflow-pdf-backed:v3:' + signature;
    const originals = Object.fromEntries(nodes.map((node) => [node.dataset.editKey, node.textContent || '']));
    const initialOverrides = Object.fromEntries(nodes.map((node) => [node.dataset.editKey, node.dataset.initialOverride === 'true']));
    const status = document.getElementById('editor-status');
    const button = document.getElementById('tailor-edit-toggle');
    let editing = false;
    let timer = 0;
    const setStatus = (value) => { if (status) status.textContent = value; };
    const number = (value) => Number(value || 0);
    const overlaps = (left, right) => {
      const leftStart = number(left.dataset.baseX);
      const rightStart = number(right.dataset.baseX);
      const leftWidth = number(left.dataset.baseWidth);
      const rightWidth = number(right.dataset.baseWidth);
      const overlap = Math.max(0, Math.min(leftStart + leftWidth, rightStart + rightWidth) - Math.max(leftStart, rightStart));
      return overlap / Math.max(1, Math.min(leftWidth, rightWidth)) >= .2;
    };
    const setRepainted = (node, value) => {
      const flag = value ? 'true' : 'false';
      node.dataset.repainted = flag;
      (erasersByBlock.get(node.dataset.blockId || '') || []).forEach((eraser) => { eraser.dataset.repainted = flag; });
    };
    const hasTextChange = (node) => initialOverrides[node.dataset.editKey]
      || (node.textContent || '') !== (originals[node.dataset.editKey] || '');
    const refreshRegion = (region, activeNode = null) => {
      const regionNodes = [...region.querySelectorAll('[data-edit-key]')];
      regionNodes.forEach((node) => {
        const shifted = Math.abs(Number.parseFloat(node.style.getPropertyValue('--flow-shift')) || 0) > .25;
        setRepainted(node, hasTextChange(node) || shifted || (editing && node === activeNode));
      });
      region.classList.toggle('is-modified', regionNodes.some(hasTextChange));
    };
    const refreshFont = (node) => {
      const sourceGlyphs = new Set([...(node.dataset.sourceGlyphs || '')]);
      const needsFallback = node.dataset.fontSubset === 'true' && [...(node.textContent || '')]
        .some((character) => !/[s​-‍\uFEFF]/.test(character) && !sourceGlyphs.has(character));
      node.classList.toggle('uses-fallback-font', needsFallback);
      return needsFallback;
    };
    const fallbackCount = () => nodes.reduce((count, node) => count + (refreshFont(node) ? 1 : 0), 0);
    const reflowRegion = (region, activeNode = document.activeElement?.closest?.('[data-edit-key]') || null) => {
      const regionNodes = [...region.querySelectorAll('[data-edit-key]')].sort((left, right) => number(left.dataset.baseTop) - number(right.dataset.baseTop) || number(left.dataset.baseX) - number(right.dataset.baseX));
      const states = [];
      let overflow = false;
      const contentLimit = Math.max(region.clientHeight, number(region.dataset.baseContentBottom));
      regionNodes.forEach((node) => {
        const top = number(node.dataset.baseTop);
        const predecessor = [...states]
          .filter((state) => state.top < top - .5 && overlaps(state.node, node))
          .sort((left, right) => right.bottom - left.bottom)[0];
        const shift = predecessor ? predecessor.shift + predecessor.delta : 0;
        node.style.setProperty('--flow-shift', shift.toFixed(2) + 'px');
        const baseline = number(node.dataset.renderedBaseHeight) || Math.max(number(node.dataset.baseHeight), node.scrollHeight);
        const actual = Math.max(Number.parseFloat(getComputedStyle(node).lineHeight) || 1, node.scrollHeight);
        const delta = actual - baseline;
        const bottom = top + shift + actual;
        states.push({ node, top, bottom, shift, delta });
        if (bottom > contentLimit + 1) overflow = true;
      });
      region.dataset.overflow = overflow ? 'true' : 'false';
      refreshRegion(region, activeNode);
      return overflow;
    };
    const reflowAll = () => {
      let overflow = false;
      regions.forEach((region) => { overflow = reflowRegion(region) || overflow; });
      return overflow;
    };
    const activateNode = (node) => {
      const region = node?.closest?.('.edit-region');
      if (!region) return;
      regions.forEach((candidate) => {
        candidate.classList.toggle('is-active', candidate === region);
        refreshRegion(candidate, candidate === region ? node : null);
      });
      requestAnimationFrame(() => reflowRegion(region, node));
    };
    const save = () => {
      localStorage.setItem(key, JSON.stringify(Object.fromEntries(nodes.map((node) => [node.dataset.editKey, node.textContent || '']))));
      const count = fallbackCount();
      setStatus(count
        ? count + ' 个段落含原 PDF 子集字体没有的新字符，已整段切换为最接近的完整字体。'
        : '改动已自动保存到此浏览器。');
    };
    const setEditing = (value) => {
      editing = value;
      document.body.classList.toggle('editing', value);
      nodes.forEach((node) => node.setAttribute('contenteditable', value ? 'plaintext-only' : 'false'));
      if (!value) {
        document.activeElement?.blur?.();
        regions.forEach((region) => region.classList.remove('is-active'));
      }
      if (button) button.textContent = value ? '完成编辑' : '开始编辑';
      setStatus(value ? '编辑已开启；点击一个段落后直接修改，未改区域保持原 PDF。' : '编辑已关闭。');
      requestAnimationFrame(() => regions.forEach((region) => refreshRegion(region)));
    };
    button?.addEventListener('click', () => setEditing(!editing));
    document.getElementById('tailor-print')?.addEventListener('click', () => {
      setEditing(false);
      if (reflowAll()) { setStatus('有文字超出原版区域，请删减内容后再保存 PDF。'); return; }
      setTimeout(() => window.print(), 60);
    });
    document.getElementById('tailor-reset')?.addEventListener('click', () => {
      if (!confirm('恢复到当前 HTML 中的定制文字？')) return;
      localStorage.removeItem(key);
      nodes.forEach((node) => {
        node.textContent = originals[node.dataset.editKey] || '';
        node.style.minHeight = '';
        refreshFont(node);
      });
      nodes.forEach((node) => setRepainted(node, initialOverrides[node.dataset.editKey]));
      regions.forEach((region) => region.classList.toggle('is-modified', region.dataset.initialOverride === 'true'));
      reflowAll();
      setEditing(false);
      setStatus('已恢复当前 HTML 版本。');
    });
    document.getElementById('tailor-save-html')?.addEventListener('click', async () => {
      setEditing(false);
      const clone = document.documentElement.cloneNode(true);
      clone.querySelectorAll('[contenteditable]').forEach((node) => node.setAttribute('contenteditable', 'false'));
      clone.querySelector('body')?.classList.remove('editing');
      const content = '<!doctype html>\\n' + clone.outerHTML;
      const name = (document.title || 'resume').replace(/[\\\\/:*?"<>|]/g, '-') + '.html';
      if ('showSaveFilePicker' in window) {
        const handle = await showSaveFilePicker({ suggestedName: name, types: [{ description: 'HTML', accept: { 'text/html': ['.html'] } }] });
        const writable = await handle.createWritable(); await writable.write(content); await writable.close(); setStatus('HTML 已保存。');
      } else {
        const url = URL.createObjectURL(new Blob([content], { type: 'text/html;charset=utf-8' }));
        const link = Object.assign(document.createElement('a'), { href: url, download: name }); link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000); setStatus('已开始下载编辑后的 HTML。');
      }
    });
    nodes.forEach((node) => {
      node.addEventListener('pointerdown', () => editing && activateNode(node));
      node.addEventListener('focus', () => editing && activateNode(node));
      node.addEventListener('paste', (event) => {
        if (!editing) return;
        event.preventDefault();
        document.execCommand('insertText', false, event.clipboardData?.getData('text/plain') || '');
      });
      node.addEventListener('input', () => {
        node.style.minHeight = getComputedStyle(node).lineHeight;
        refreshFont(node);
        reflowRegion(node.closest('.edit-region'));
        clearTimeout(timer);
        timer = setTimeout(save, 250);
      });
    });
    window.addEventListener('message', (event) => {
      const mapId = String(event.data?.mapId || '');
      if (event.data?.type !== 'OFFERFLOW_HIGHLIGHT_MAP' || !mapId) return;
      nodes.forEach((node) => {
        const active = (node.dataset.mapIds || '').split(/\\s+/).includes(mapId);
        node.dataset.active = active ? 'true' : 'false';
        if (active) activateNode(node);
      });
      setStatus(mapId + ' · 已高亮原 PDF 中的对应内容');
    });
    const initialize = async () => {
      try { await document.fonts?.ready; } catch {}
      await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
      // Measure reflow against the source PDF geometry, never against the
      // already-tailored DOM. Initial PDF patches are present before this
      // script starts; using scrollHeight here made their added height look
      // like the baseline, so following blocks stayed at their old positions
      // and the two paragraphs were painted on top of each other.
      nodes.forEach((node) => {
        const sourceHeight = Math.max(
          number(node.dataset.baseHeight),
          Number.parseFloat(getComputedStyle(node).lineHeight) || 1
        );
        node.dataset.renderedBaseHeight = String(sourceHeight);
      });
      regions.forEach((region) => {
        const bottom = Math.max(0, ...[...region.querySelectorAll('[data-edit-key]')].map((node) => number(node.dataset.baseTop) + number(node.dataset.renderedBaseHeight)));
        region.dataset.baseContentBottom = String(bottom);
      });
      try {
        const saved = JSON.parse(localStorage.getItem(key) || 'null');
        nodes.forEach((node) => {
          if (saved?.[node.dataset.editKey] !== undefined) node.textContent = String(saved[node.dataset.editKey]);
          refreshFont(node);
        });
      } catch {}
      regions.forEach(refreshRegion);
      if (nodes.some(hasTextChange)) reflowAll();
      setEditing(false);
      if (button) {
        button.disabled = nodes.length === 0;
        if (!nodes.length) button.title = '当前 PDF 未提取到可编辑文字';
      }
    };
    initialize();
  })();`}const d=e=>e.replace(/[&<>"']/g,t=>{switch(t){case"&":return"&amp;";case"<":return"&lt;";case">":return"&gt;";case'"':return"&quot;";default:return"&#39;"}});function Fn(e){const{resume:t,jd:a,pageSize:s="a4",accentColor:o="#1d4ed8",photoDataUrl:r,showJdSidebar:i=!0,variant:p="modern",sourceProfile:h}=e,c=Ln(s),l=a||{source:"fallback",responsibility:[],must_haves:[],differentiators:[],bonus:[],keywords:[],mappings:[]},m=Hn(t,l),u=zn({layout:c,accentColor:o,variant:p}),x=In(),y=i?An(l):"",j=Rn({resume:t,photoDataUrl:r,idMap:m,showSummary:p!=="source-aligned"||!!(h!=null&&h.selfIntroduction||h!=null&&h.strengths),showTargetIntent:p!=="source-aligned"});return`<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="generator" content="offerflow-tailor">
  <title>${d(t.targetCompany||"")} · ${d(t.targetRole||"")} · ${d(t.header.name||"定制简历")}</title>
  <style>${u}</style>
</head>
<body class="surface ${p}">
  ${x}
  <div class="layout ${i?"with-jd":"no-jd"}">
    ${y}
    <main class="page" id="resume" data-page-width-pt="${c.widthPt}" data-page-height-pt="${c.heightPt}">
      ${j}
    </main>
  </div>
  <script>${Jn()}<\/script>
</body>
</html>`}function Ln(e){return e==="letter"?{widthPx:816,heightPx:1056,widthPt:612,heightPt:792,paddingTop:60,paddingBottom:60,paddingSide:64}:{widthPx:794,heightPx:1123,widthPt:595,heightPt:842,paddingTop:56,paddingBottom:56,paddingSide:60}}function zn({layout:e,accentColor:t,variant:a}){return`
  @page { size: ${e.widthPt}pt ${e.heightPt}pt; margin: 0; }
  :root {
    --page-width: ${e.widthPx}px;
    --page-height: ${e.heightPx}px;
    --padding-top: ${e.paddingTop}px;
    --padding-side: ${e.paddingSide}px;
    --padding-bottom: ${e.paddingBottom}px;
    --accent: ${t};
    --ink: #0f172a;
    --muted: #475569;
    --line: #e2e8f0;
    --chip: #f1f5f9;
    --body-font: 10.5px;
  }
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; }
  body {
    background: #f5f6f8;
    color: var(--ink);
    font-family: "Inter", "Helvetica Neue", "PingFang SC", "Microsoft YaHei", "Source Han Sans SC", "Noto Sans CJK SC", sans-serif;
    font-size: var(--body-font);
    line-height: 1.55;
    -webkit-font-smoothing: antialiased;
    text-rendering: geometricPrecision;
  }
  .surface {
    display: flex;
    flex-direction: column;
    min-height: 100vh;
  }
  .layout {
    display: flex;
    gap: 24px;
    padding: 32px 24px 80px;
    align-items: flex-start;
    justify-content: center;
  }
  .layout.with-jd { max-width: 1240px; margin: 0 auto; }
  .layout.no-jd .page { margin: 0 auto; }
  .jd-sidebar {
    flex: 0 0 320px;
    background: #ffffff;
    border-radius: 16px;
    box-shadow: 0 14px 40px rgba(15, 23, 42, 0.08);
    padding: 18px 18px 22px;
    max-height: calc(100vh - 120px);
    overflow-y: auto;
    position: sticky;
    top: 88px;
  }
  .jd-sidebar h2 {
    margin: 0 0 6px;
    font-size: 13px;
    font-weight: 600;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    color: var(--muted);
  }
  .jd-sidebar .eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 3px 8px;
    background: var(--chip);
    color: var(--accent);
    font-size: 10px;
    font-weight: 600;
    border-radius: 999px;
    letter-spacing: 0.06em;
  }
  .jd-sidebar .panel-title {
    font-size: 14px;
    font-weight: 600;
    margin: 16px 0 8px;
    color: var(--ink);
  }
  .jd-sidebar ul {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 6px;
  }
  .jd-card {
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 8px 10px;
    cursor: pointer;
    transition: border-color .15s ease, box-shadow .15s ease, background .15s ease;
    background: #ffffff;
  }
  .jd-card[data-active="true"] {
    border-color: var(--accent);
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.16);
    background: rgba(37, 99, 235, 0.06);
  }
  .jd-card strong { display: block; font-size: 11px; color: var(--ink); margin-bottom: 3px; }
  .jd-card span { color: var(--muted); font-size: 10.5px; }
  .jd-card[data-active="true"] strong { color: var(--accent); }
  .jd-card .map-id {
    display: inline-block;
    font-size: 9.5px;
    font-family: "JetBrains Mono", "Menlo", monospace;
    color: var(--muted);
    margin-bottom: 2px;
  }
  .jd-sidebar .keywords {
    display: flex;
    flex-wrap: wrap;
    gap: 4px;
    margin-top: 6px;
  }
  .jd-sidebar .keywords span {
    background: var(--chip);
    color: var(--muted);
    font-size: 10px;
    padding: 3px 7px;
    border-radius: 999px;
  }
  .page {
    flex: 0 0 auto;
    width: var(--page-width);
    min-height: var(--page-height);
    background: #ffffff;
    padding: var(--padding-top) var(--padding-side) var(--padding-bottom);
    box-shadow: 0 14px 40px rgba(15, 23, 42, 0.12);
    border-radius: 6px;
    color: var(--ink);
    overflow: visible;
    position: relative;
  }
  .page header {
    border-bottom: 0.5px solid var(--line);
    padding-bottom: 14px;
    margin-bottom: 16px;
    display: grid;
    grid-template-columns: 1fr auto;
    gap: 18px;
    align-items: flex-end;
  }
  .page header .identity { display: flex; flex-direction: column; gap: 6px; }
  .page header h1 {
    margin: 0;
    font-size: 24px;
    line-height: 1.15;
    font-weight: 700;
    letter-spacing: 0.01em;
  }
  .page header .headline {
    color: var(--accent);
    font-weight: 600;
    font-size: 12.5px;
    letter-spacing: 0.04em;
  }
  .page header .meta-row {
    display: flex;
    flex-wrap: wrap;
    gap: 6px 12px;
    color: var(--muted);
    font-size: 11px;
  }
  .page header .meta-row .divider { color: #cbd5e1; }
  .page header .meta-row a {
    color: var(--accent);
    text-decoration: none;
  }
  .page header .meta-row a:hover { text-decoration: underline; }
  .page header .photo {
    width: 92px;
    height: 116px;
    object-fit: cover;
    border-radius: 6px;
    border: 0.5px solid var(--line);
  }
  .page section { margin: 0 0 14px; }
  .page section:last-child { margin-bottom: 0; }
  .page h2 {
    margin: 0 0 6px;
    padding-bottom: 4px;
    border-bottom: 1.5px solid var(--accent);
    font-size: 11.5px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.18em;
    color: var(--accent);
  }
  .summary {
    margin: 0;
    color: var(--ink);
    line-height: 1.6;
  }
  .entry {
    margin-bottom: 10px;
    page-break-inside: avoid;
  }
  .entry:last-child { margin-bottom: 0; }
  .entry-head {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    gap: 12px;
    align-items: baseline;
    font-size: 11.5px;
    font-weight: 600;
  }
  .entry-head .role {
    display: block;
    font-size: 10px;
    color: var(--muted);
    margin-top: 2px;
    font-weight: 500;
  }
  .entry-head .date {
    font-size: 10.5px;
    color: var(--muted);
    font-weight: 500;
    white-space: nowrap;
  }
  .entry-head .label {
    color: var(--ink);
    font-weight: 700;
  }
  .bullets {
    list-style: none;
    margin: 4px 0 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
  .bullets li {
    position: relative;
    padding-left: 14px;
    line-height: 1.55;
  }
  .bullets li::before {
    content: "";
    position: absolute;
    left: 4px;
    top: 0.6em;
    width: 4px;
    height: 4px;
    border-radius: 50%;
    background: var(--accent);
    opacity: 0.7;
  }
  .bullets li[data-active="true"] {
    background: rgba(37, 99, 235, 0.08);
    border-radius: 4px;
    transition: background .25s ease;
  }
  .skill-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
    gap: 6px 10px;
  }
  .skill-group { display: flex; flex-direction: column; gap: 4px; }
  .skill-group .label {
    font-size: 10px;
    color: var(--muted);
    letter-spacing: 0.05em;
    text-transform: uppercase;
    font-weight: 600;
  }
  .skill-group .items {
    display: flex;
    flex-wrap: wrap;
    gap: 4px;
  }
  .skill-group .chip {
    background: var(--chip);
    color: var(--ink);
    padding: 2px 8px;
    border-radius: 999px;
    font-size: 10.5px;
  }
  .compact-list {
    display: flex;
    flex-direction: column;
    gap: 3px;
    margin: 0;
    padding: 0;
  }
  .compact-list li {
    display: grid;
    grid-template-columns: 1fr auto;
    gap: 10px;
    color: var(--ink);
    font-size: 11px;
  }
  .compact-list .meta { color: var(--muted); font-size: 10px; }
  .interests {
    margin: 0;
    color: var(--muted);
    font-size: 11px;
  }
  .toolbar {
    position: sticky;
    top: 0;
    z-index: 50;
    display: flex;
    gap: 8px;
    align-items: center;
    padding: 12px 20px;
    background: rgba(255, 255, 255, 0.94);
    backdrop-filter: blur(8px);
    border-bottom: 1px solid var(--line);
  }
  .toolbar .title { font-weight: 700; font-size: 13px; letter-spacing: 0.02em; }
  .toolbar .subtitle { color: var(--muted); font-size: 11.5px; }
  .toolbar .actions { display: flex; gap: 6px; margin-left: auto; }
  .toolbar button {
    border: 1px solid #cbd5e1;
    background: #ffffff;
    color: var(--ink);
    border-radius: 8px;
    padding: 7px 12px;
    font: inherit;
    font-size: 12px;
    cursor: pointer;
    transition: border-color .15s ease, color .15s ease, background-color .15s ease, filter .15s ease;
  }
  .toolbar button:hover { border-color: var(--accent); color: var(--accent); }
  .toolbar button.primary { background: var(--accent); border-color: var(--accent); color: #ffffff; }
  .toolbar button.primary:hover { filter: brightness(1.05); color: #ffffff; }
  .toolbar .status { color: var(--muted); font-size: 11px; margin-left: 8px; }
  body.editing [data-edit-key] { background: #fff8d5; outline: 1px dashed #d6a800; border-radius: 2px; }
  ${a==="source-aligned"?`
  body.source-aligned {
    --accent: #202421;
    --ink: #151816;
    --muted: #4f5752;
    --line: #cfd4d0;
    --chip: transparent;
    font-family: Arial, "Microsoft YaHei", "PingFang SC", "Noto Sans CJK SC", sans-serif;
    line-height: 1.5;
  }
  .source-aligned .page {
    padding: 46px 52px 52px;
    border-radius: 0;
  }
  .source-aligned .page header {
    display: block;
    padding-bottom: 12px;
    margin-bottom: 13px;
    border-bottom: 1px solid var(--ink);
    text-align: center;
  }
  .source-aligned .page header .identity { align-items: center; gap: 5px; }
  .source-aligned .page header h1 { font-size: 22px; letter-spacing: .04em; }
  .source-aligned .page header .headline { color: var(--ink); font-size: 11px; letter-spacing: .02em; }
  .source-aligned .page header .meta-row { justify-content: center; color: #343a36; }
  .source-aligned .page section { margin-bottom: 12px; }
  .source-aligned .page h2 {
    margin-bottom: 7px;
    padding-bottom: 3px;
    border-bottom: 1px solid var(--ink);
    color: var(--ink);
    font-size: 13px;
    letter-spacing: .02em;
    text-transform: none;
  }
  .source-aligned .entry { margin-bottom: 9px; }
  .source-aligned .entry-head { font-size: 11px; }
  .source-aligned .bullets { gap: 1px; margin-top: 3px; }
  .source-aligned .bullets li { padding-left: 13px; }
  .source-aligned .bullets li::before { left: 3px; width: 3px; height: 3px; background: var(--ink); opacity: 1; }
  .source-aligned .skill-grid { grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 4px 16px; }
  .source-aligned .skill-group .items { gap: 3px 10px; }
  .source-aligned .skill-group .chip { padding: 0; border-radius: 0; background: transparent; }
  `:""}
  @media print {
    html, body { background: #ffffff; }
    .layout { padding: 0; gap: 0; }
    .jd-sidebar { display: none; }
    .toolbar { display: none !important; }
    .page {
      box-shadow: none;
      border-radius: 0;
      margin: 0;
      width: var(--page-width);
      min-height: var(--page-height);
      height: auto;
    }
    body.editing [data-edit-key] { background: transparent; outline: none; }
    .bullets li[data-active="true"] { background: transparent; }
  }
  `}function In(){return`<aside class="toolbar" aria-label="简历编辑工具">
    <span class="title">流式编辑简历</span>
    <span class="subtitle">按完整段落编辑；增删文字会自动换行和重排。</span>
    <span class="status" id="editor-status">点击「开始编辑」后可直接修改完整字段和经历描述。</span>
    <span class="actions">
      <button type="button" id="tailor-edit-toggle" class="primary">开始编辑</button>
      <button type="button" id="tailor-save-html">保存 HTML</button>
      <button type="button" id="tailor-reset">恢复文件版本</button>
      <button type="button" id="tailor-print">保存为 PDF</button>
    </span>
  </aside>`}function An(e){const t=[],a=(s,o,r)=>{s.forEach((i,p)=>{const h=e.mappings.find(l=>l.text===i&&l.category===o),c=(h==null?void 0:h.map_id)||`JD-${o.toUpperCase()}-${p+1}`;t.push(`<li class="jd-card" data-map-id="${d(c)}">
          <span class="map-id">${d(c)}</span>
          <strong>${d(r)}</strong>
          <span>${d(i)}</span>
        </li>`)})};return a(e.responsibility,"responsibility","工作职责"),a(e.must_haves,"requirement","硬性要求"),a(e.differentiators,"differentiator","加分项"),a(e.bonus,"bonus","额外优势"),a(e.keywords,"keyword","关键词"),`<aside class="jd-sidebar" aria-label="JD 映射">
    <h2>JD 映射</h2>
    <span class="eyebrow">${e.source==="deepseek"?"DeepSeek 定制":"本地兜底"}</span>
    ${e.responsibility.length?`<p class="panel-title">工作职责</p><ul>${t.filter(s=>s.includes("工作职责")).join("")}</ul>`:""}
    ${e.must_haves.length?`<p class="panel-title">硬性要求</p><ul>${t.filter(s=>s.includes("硬性要求")).join("")}</ul>`:""}
    ${e.differentiators.length?`<p class="panel-title">加分项</p><ul>${t.filter(s=>s.includes("加分项")).join("")}</ul>`:""}
    ${e.bonus.length?`<p class="panel-title">额外优势</p><ul>${t.filter(s=>s.includes("额外优势")).join("")}</ul>`:""}
    ${e.keywords.length?`<p class="panel-title">关键词</p>
         <div class="keywords">${e.keywords.map(s=>`<span data-map-id="${d(`JD-KEYWORD-${s}`)}">${d(s)}</span>`).join("")}</div>`:""}
    <p class="panel-title" style="margin-top:18px">点击 JD 卡片 · 高亮简历对应 bullet</p>
  </aside>`}function Rn({resume:e,photoDataUrl:t,idMap:a,showSummary:s,showTargetIntent:o}){const{header:r,summary:i}=e,p=`
    <header>
      <div class="identity">
        <h1 data-edit-key="header.name">${d(r.name)}</h1>
        <span class="headline" data-edit-key="header.headline">${d(e.targetRole||r.headline)}</span>
        <div class="meta-row">
          ${r.email?`<span data-edit-key="header.email">${d(r.email)}</span>`:""}
          ${r.email&&r.phone?'<span class="divider">·</span>':""}
          ${r.phone?`<span data-edit-key="header.phone">${d(r.phone)}</span>`:""}
          ${(r.email||r.phone)&&r.city?'<span class="divider">·</span>':""}
          ${r.city?`<span data-edit-key="header.city">${d(r.city)}</span>`:""}
          ${r.links.filter(g=>g.href).map(g=>`<a href="${d(g.href)}" data-edit-key="header.link.${d(g.label)}">${d(g.label)}</a>`).join('<span class="divider">·</span>')}
        </div>
        ${o&&e.targetCompany?`<div class="meta-row" style="margin-top:6px;"><strong style="color:var(--ink);font-size:11px;">意向：</strong><span data-edit-key="resume.targetCompany">${d(e.targetCompany)}</span><span class="divider">·</span><span data-edit-key="resume.targetRole">${d(e.targetRole)}</span></div>`:""}
      </div>
      ${t?`<img src="${d(t)}" alt="证件照" class="photo" />`:""}
    </header>
  `,h=s&&i?`<section>
        <h2>个人摘要</h2>
        <p class="summary" data-edit-key="resume.summary">${d(i)}</p>
      </section>`:"",c=e.education.length?`<section>
        <h2>教育经历</h2>
        ${e.education.map(g=>On(g,a)).join("")}
      </section>`:"",l=e.experience.length?`<section>
        <h2>实习 / 工作经历</h2>
        ${e.experience.map(g=>_n(g,a)).join("")}
      </section>`:"",m=e.projects.length?`<section>
        <h2>项目经历</h2>
        ${e.projects.map(g=>Bn(g,a)).join("")}
      </section>`:"",u=e.campus.length?`<section>
        <h2>在校经历</h2>
        <div class="compact-list">
          ${e.campus.map(g=>`<li>
                <span><strong data-edit-key="campus.${d(g.id)}.role">${d(g.type)} · ${d(g.role)}</strong>
                  <small style="display:block;color:var(--muted);font-size:10.5px;" data-edit-key="campus.${d(g.id)}.description">${d(g.description)}</small>
                </span>
                <span class="meta" data-edit-key="campus.${d(g.id)}.date">${d(de(g.start,g.end))}</span>
              </li>`).join("")}
        </div>
      </section>`:"",x=e.awards.length?`<section>
        <h2>获奖情况</h2>
        <div class="compact-list">
          ${e.awards.map(g=>`<li>
                <span><strong data-edit-key="award.${d(g.id)}.name">${d(g.name)}</strong>${g.level?`<small style="color:var(--muted);">${d(g.level)}</small>`:""}</span>
                <span class="meta" data-edit-key="award.${d(g.id)}.date">${d(g.date)}</span>
              </li>`).join("")}
        </div>
      </section>`:"",y=e.skills.length?`<section>
        <h2>技能 / 证书</h2>
        <div class="skill-grid">
          ${e.skills.map(g=>`<div class="skill-group">
                <span class="label">${d(g.label)}</span>
                <span class="items">${g.items.map(D=>`<span class="chip" data-edit-key="skill.${d(g.id)}.${d(D)}">${d(D)}</span>`).join("")}</span>
              </div>`).join("")}
        </div>
      </section>`:"",j=e.languages.length?`<section>
        <h2>语言</h2>
        <div class="compact-list">
          ${e.languages.map(g=>`<li>
                <span><strong data-edit-key="language.${d(g.id)}.name">${d(g.name)}</strong></span>
                <span class="meta" data-edit-key="language.${d(g.id)}.level">${d(g.level)}</span>
              </li>`).join("")}
        </div>
      </section>`:"",N=e.publications.length?`<section>
        <h2>论文 / 专利</h2>
        <div class="compact-list">
          ${e.publications.map(g=>`<li>
                <span><strong data-edit-key="publication.${d(g.id)}.title">${d(g.title)}</strong>${g.venue?`<small style="color:var(--muted);"> · ${d(g.venue)}</small>`:""}</span>
                <span class="meta" data-edit-key="publication.${d(g.id)}.date">${d(g.date)}</span>
              </li>`).join("")}
        </div>
      </section>`:"",F=e.interests.length?`<section>
        <h2>兴趣爱好</h2>
        <p class="interests" data-edit-key="resume.interests">${d(e.interests.join(" · "))}</p>
      </section>`:"";return[p,h,c,l,m,u,x,y,j,N,F].filter(Boolean).join(`
`)}function On(e,t){const a=`${e.school}${e.major?` · ${e.major}`:""}`,s=de(e.start,e.end),o=t.get(e.id)||"";return`<div class="entry" data-resume-id="${d(e.id)}" data-map-ids="${d(o)}">
    <div class="entry-head">
      <div>
        <span class="label" data-edit-key="edu.${d(e.id)}.label">${d(a)}</span>
        <span class="role" data-edit-key="edu.${d(e.id)}.degree">${d([e.degree,e.gpa?`GPA ${e.gpa}`:"",e.rank].filter(Boolean).join(" · "))}</span>
      </div>
      <span class="date" data-edit-key="edu.${d(e.id)}.date">${d(s)}</span>
    </div>
    ${e.highlights.length?`<ul class="bullets">${e.highlights.map((r,i)=>`<li data-edit-key="edu.${d(e.id)}.highlight.${i}" data-resume-id="${d(e.id)}.highlight-${i}" data-map-ids="${d(o)}">${d(r)}</li>`).join("")}</ul>`:""}
    ${e.courses?`<p style="margin:4px 0 0;color:var(--muted);font-size:10.5px;" data-edit-key="edu.${d(e.id)}.courses">主修课程：${d(e.courses)}</p>`:""}
  </div>`}function _n(e,t){const a=de(e.start,e.end),s=t.get(e.id)||"";return`<div class="entry" data-resume-id="${d(e.id)}" data-map-ids="${d(s)}">
    <div class="entry-head">
      <div>
        <span class="label" data-edit-key="exp.${d(e.id)}.company">${d(e.company)}</span>
        <span class="role" data-edit-key="exp.${d(e.id)}.title">${d(e.title)}${e.location?` · ${d(e.location)}`:""}</span>
      </div>
      <span class="date" data-edit-key="exp.${d(e.id)}.date">${d(a)}</span>
    </div>
    ${e.bullets.length?`<ul class="bullets">${e.bullets.map((o,r)=>`<li data-edit-key="exp.${d(e.id)}.bullet.${r}" data-resume-id="${d(e.id)}.bullet-${r}" data-map-ids="${d(s)}">${d(o)}</li>`).join("")}</ul>`:""}
  </div>`}function Bn(e,t){const a=de(e.start,e.end),s=t.get(e.id)||"";return`<div class="entry" data-resume-id="${d(e.id)}" data-map-ids="${d(s)}">
    <div class="entry-head">
      <div>
        <span class="label" data-edit-key="project.${d(e.id)}.name">${d(e.name)}</span>
        <span class="role" data-edit-key="project.${d(e.id)}.role">${d(e.role)}${e.link?` · ${d(e.link)}`:""}</span>
        ${e.summary?`<p style="margin:4px 0 0;color:var(--muted);font-size:10.5px;" data-edit-key="project.${d(e.id)}.summary">${d(e.summary)}</p>`:""}
      </div>
      <span class="date" data-edit-key="project.${d(e.id)}.date">${d(a)}</span>
    </div>
    ${e.bullets.length?`<ul class="bullets">${e.bullets.map((o,r)=>`<li data-edit-key="project.${d(e.id)}.bullet.${r}" data-resume-id="${d(e.id)}.bullet-${r}" data-map-ids="${d(s)}">${d(o)}</li>`).join("")}</ul>`:""}
  </div>`}function de(e,t){return!e&&!t?"":e&&t?`${e} – ${t}`:e||t}function Hn(e,t){const a=new Map,s=[...e.experience.map(o=>o.id),...e.projects.map(o=>o.id),...e.education.map(o=>o.id)];return t.mappings.forEach(o=>{o.resume_ids.forEach(r=>{if(!s.includes(r.split(".")[0]))return;const i=a.get(r.split(".")[0])||"";a.set(r.split(".")[0],`${i} ${o.map_id}`.trim())})}),a}function Jn(){return`(() => {
    const nodes = [...document.querySelectorAll('[data-edit-key]')];
    const storageKey = 'offerflow-tailor:' + document.title;
    const originals = Object.fromEntries(nodes.map((node) => [node.dataset.editKey, node.innerHTML]));
    const status = document.getElementById('editor-status');
    const editButton = document.getElementById('tailor-edit-toggle');
    let editing = false;
    let saveTimer = 0;

    const setStatus = (msg) => { status.textContent = msg; };
    const snapshot = () => Object.fromEntries(nodes.map((node) => [node.dataset.editKey, node.innerHTML]));
    const persist = () => {
      try {
        localStorage.setItem(storageKey, JSON.stringify(snapshot()));
        setStatus('草稿已自动保存到此浏览器。');
      } catch (error) {
        setStatus('草稿保存失败：' + error.message);
      }
    };
    const restoreDraft = () => {
      try {
        const saved = JSON.parse(localStorage.getItem(storageKey) || 'null');
        if (!saved) return false;
        let restored = 0;
        nodes.forEach((node) => {
          if (saved[node.dataset.editKey] !== undefined) {
            node.innerHTML = saved[node.dataset.editKey];
            restored += 1;
          }
        });
        setStatus(restored ? '已恢复此浏览器中的本地草稿。' : '');
        return restored > 0;
      } catch (error) {
        setStatus('本地草稿读取失败：' + error.message);
        return false;
      }
    };
    const setEditing = (enabled) => {
      editing = enabled;
      document.body.classList.toggle('editing', enabled);
      nodes.forEach((node) => node.setAttribute('contenteditable', enabled ? 'true' : 'false'));
      editButton.textContent = enabled ? '完成编辑' : '开始编辑';
      setStatus(enabled ? '编辑已开启 · 改动会自动保存。' : '编辑已关闭 · 点击「保存为 PDF」导出。');
    };

    editButton.addEventListener('click', () => setEditing(!editing));
    document.getElementById('tailor-print').addEventListener('click', () => {
      setEditing(false);
      setTimeout(() => window.print(), 60);
    });
    document.getElementById('tailor-reset').addEventListener('click', () => {
      if (!confirm('恢复到当前 HTML 文件中的文字？浏览器本地草稿会被删除。')) return;
      localStorage.removeItem(storageKey);
      nodes.forEach((node) => { node.innerHTML = originals[node.dataset.editKey] || ''; });
      setEditing(false);
      setStatus('已恢复文件版本。');
    });
    document.getElementById('tailor-save-html').addEventListener('click', async () => {
      setEditing(false);
      const clone = document.documentElement.cloneNode(true);
      clone.querySelectorAll('[contenteditable]').forEach((node) => node.setAttribute('contenteditable', 'false'));
      clone.querySelector('body').classList.remove('editing');
      const content = '<!doctype html>\\n' + clone.outerHTML;
      const suggested = (document.title || 'resume').replace(/[\\\\/:*?"<>|]/g, '-') + '.html';
      try {
        if ('showSaveFilePicker' in window) {
          const handle = await showSaveFilePicker({ suggestedName: suggested, types: [{ description: 'HTML', accept: { 'text/html': ['.html'] } }] });
          const writable = await handle.createWritable();
          await writable.write(content);
          await writable.close();
          setStatus('HTML 已保存。');
        } else {
          const url = URL.createObjectURL(new Blob([content], { type: 'text/html;charset=utf-8' }));
          const link = Object.assign(document.createElement('a'), { href: url, download: suggested });
          link.click();
          setTimeout(() => URL.revokeObjectURL(url), 1000);
          setStatus('浏览器已开始下载编辑后的 HTML。');
        }
      } catch (error) {
        if (error && error.name !== 'AbortError') setStatus('保存失败：' + error.message);
      }
    });
    nodes.forEach((node) => node.addEventListener('input', () => {
      clearTimeout(saveTimer);
      saveTimer = setTimeout(persist, 250);
    }));

    // JD → Resume cross-highlight
    const cards = [...document.querySelectorAll('.jd-card, .jd-sidebar .keywords span')];
    const bullets = [...document.querySelectorAll('.bullets li[data-resume-id]')];
    const highlightMap = (mapId) => {
      if (!mapId) return;
      cards.forEach((other) => other.dataset.active = 'false');
      cards
        .filter((card) => card.dataset.mapId === mapId)
        .forEach((card) => card.dataset.active = 'true');
      bullets.forEach((bullet) => {
        const ids = bullet.dataset.mapIds || bullet.closest('.entry')?.dataset.mapIds || '';
        bullet.dataset.active = ids.split(/\\s+/).includes(mapId) ? 'true' : 'false';
      });
      setStatus(mapId + ' · 已高亮映射 bullet');
    };
    cards.forEach((card) => {
      const mapId = card.dataset.mapId;
      if (!mapId) return;
      card.addEventListener('click', () => highlightMap(mapId));
    });
    window.addEventListener('message', (event) => {
      if (event.data?.type === 'OFFERFLOW_HIGHLIGHT_MAP') highlightMap(String(event.data.mapId || ''));
    });

    restoreDraft();
    setEditing(false);
  })();`}function Kn(e){const t=e.trim().replace(/^```(?:json)?\s*/i,"").replace(/\s*```$/,"").trim(),a=t.indexOf("{"),s=t.lastIndexOf("}");return a>0&&s>a?t.slice(a,s+1):t}function Un(e,t){const a=e.trim();if(!a)return!1;const s=t instanceof Error?t.message:String(t||"");return!a.endsWith("}")||/unterminated|unexpected end/i.test(s)}function qn(e){const t=Kn(e);try{return{value:JSON.parse(t),normalized:t,likelyTruncated:!1}}catch(a){const s=a instanceof Error?a:new Error(String(a));return{error:s,normalized:t,likelyTruncated:Un(t,s)}}}function tt(e,t){const a=nt(e),s=nt(t),o=[];return s.forEach((r,i)=>{const p=a.get(i);p!==void 0&&at(p)!==at(r)&&o.push({key:i,before:p,after:r})}),o}function nt(e){const t=new Map;return t.set("summary",e.summary||""),e.experience.forEach(a=>a.bullets.forEach((s,o)=>{t.set(`experience.${a.id}.bullet.${o}`,s)})),e.projects.forEach(a=>{t.set(`project.${a.id}.summary`,a.summary||""),a.bullets.forEach((s,o)=>t.set(`project.${a.id}.bullet.${o}`,s))}),e.campus.forEach(a=>t.set(`campus.${a.id}.description`,a.description||"")),e.skills.forEach(a=>a.items.forEach((s,o)=>{t.set(`skills.${a.id}.${o}`,s)})),t}function at(e){return String(e||"").replace(/\s+/g,"").trim()}const Wn="https://api.deepseek.com/chat/completions",Gn=8192,Xn=`你是 JobKoI 的简历定制助手。基于候选人已上传的真实资料 + 招聘JD的事实陈述，输出一份针对该JD量身定制的中文简历结构化 JSON。
严格要求：
1. 不得编造公司、奖项、数字、客户、模型、专利、行业、团队规模等任何事实。
2. 不得删除既有内容来"凑"JD 关键词；只能改写措辞、调整顺序。
3. 教育/工作/项目的雇主、岗位名、起止时间、学位、专业名称保持原样。
4. 每条 bullet 必须能映射到一条招聘JD里的描述，否则标 unsupported 并不要写入 resume。
5. 必须在每条 bullet 前面放一个或多个 resume_ids 与之绑定的 JD map_id，体现简历如何回应 JD。
6. 至少改写 3 条与 JD 最相关的现有 bullet：保持事实、数字和长度基本不变，但把 JD 相关能力前置；不得仅原样复制候选人简历。`;async function Vn(e,t,a,s=[]){var u,x,y,j,N,F;const o=(u=a.deepseekApiKey)==null?void 0:u.trim();if(!o)throw new Error("请先在设置中填写 DeepSeek API Key 后再生成定制简历");const r=pt(e),i=Yn(e,t,r,s);let p=await st(o,a,i),h=rt(r,p.resume||{}),c=tt(r,h),l=Ze((x=p.resume)==null?void 0:x.pdf_patches,s);if(s.length>0&&l.length===0&&(p=await st(o,a,`${i}

关键纠错：上一次没有生成可验证的 PDF 补丁。本次必须逐字复制原 PDF 文本块的 page、block_id、source_text，并为至少 ${Math.min(3,s.length)} 个文本块提供等长改写。`),h=rt(r,p.resume||{}),c=tt(r,h),l=Ze((y=p.resume)==null?void 0:y.pdf_patches,s)),s.length>0&&l.length===0)throw new Error("DeepSeek 改写了结构化简历，但没有返回能与原 PDF 文本块校验一致的补丁，已停止生成，避免再次出现‘改写有内容、落版为 0’。请重试一次。");if(c.length===0&&l.length===0)throw new Error("DeepSeek 已返回结果，但没有实际改写任何简历内容。请重新生成；系统不会再把原文复制版标记为定制成功。");const m=Qn(p.jd||{},((j=p.resume)==null?void 0:j.mapping)||[]);return{context:t,jd:m,resume:h,generatedAt:new Date().toISOString(),notes:[`已改写 ${c.length} 处结构化内容，并生成 ${l.length} 个原 PDF 定位补丁。`,...((N=p.resume)==null?void 0:N.notes)||[]],unsupportedClaims:((F=p.resume)==null?void 0:F.unsupported_claims)||[],changeSummary:{modelChanges:c.length},pdfPatches:l}}async function st(e,t,a){var r,i,p;const s=t.deepseekModel==="deepseek-v4-flash"?"deepseek-chat":t.deepseekModel||"deepseek-chat";let o="";for(let h=0;h<2;h+=1){const c=h===0?"":`

上一次输出未形成完整 JSON。请压缩 notes、rationale 和措辞，但必须返回语法完整的单个 JSON 对象，不要使用 Markdown。`,l=await fetch(Wn,{method:"POST",headers:{Authorization:`Bearer ${e}`,"Content-Type":"application/json"},body:JSON.stringify({model:s,messages:[{role:"system",content:Xn},{role:"user",content:`${a}${c}`}],response_format:{type:"json_object"},thinking:{type:"disabled"},temperature:.2,max_tokens:Gn,stream:!1})});if(!l.ok){const F=await l.text();throw new Error(`DeepSeek 定制请求失败（${l.status}）：${F.slice(0,200)}`)}const u=(r=(await l.json()).choices)==null?void 0:r[0],x=(i=u==null?void 0:u.message)==null?void 0:i.content;if(!x)throw new Error("DeepSeek 没有返回定制结果");const y=qn(x),j=(u==null?void 0:u.finish_reason)==="length";if(y.value&&!j)return y.value;o=`${j||y.likelyTruncated?"输出达到长度上限并被截断":"返回内容不是合法 JSON"}（${y.normalized.length} 字符；${((p=y.error)==null?void 0:p.message)||`finish_reason=${(u==null?void 0:u.finish_reason)||"unknown"}`}）`}throw new Error(`DeepSeek 定制结果无法解析：${o}。已自动重试，请缩短简历内容或稍后再试。`)}function Yn(e,t,a,s){const o=Zn(e,a);return`## 招聘JD（请基于此定制）
公司：${t.company}
岗位：${t.position}
${t.city?`城市：${t.city}
`:""}${t.jobType?`类型：${t.jobType}
`:""}
${t.deadline?`截止：${t.deadline}
`:""}
${t.summary?`岗位摘要：${t.summary}
`:""}
JD 职责：
${(t.responsibilities||[]).map(r=>`- ${r}`).join(`
`)||"- 暂无"}
JD 要求：
${(t.requirements||[]).map(r=>`- ${r}`).join(`
`)||"- 暂无"}
${t.rawExcerpt?`
JD 原始文本（仅供参考，避免幻觉）：
${t.rawExcerpt.slice(0,1200)}`:""}

## 候选人原始资料
\`\`\`json
${JSON.stringify(o,null,2)}
\`\`\`

## 原 PDF 可改写文本块
下面文本直接来自 PDF 坐标层。只改写其中与 JD 最相关的叙述块；必须原样复用 block_id 和 source_text。不要改教育、日期、公司、岗位、数字或专有名词。tailored_text 的字符数必须为 source_text 的 90%-110%，视觉宽度不得增加超过 8%；优先做关键词前置和同义替换，不要新增句子、bullet 或换行。
\`\`\`json
${JSON.stringify(s,null,2)}
\`\`\`

## 输出结构
\`\`\`json
{
  "jd": {
    "responsibility": ["..."],
    "must_haves": ["..."],
    "differentiators": ["..."],
    "bonus": ["..."],
    "keywords": ["..."]
  },
  "resume": {
    "targetRole": "${ot(t.position)}",
    "targetCompany": "${ot(t.company)}",
    "header": {"name":"...","headline":"...","email":"...","phone":"...","city":"...","links":[{"label":"...","href":"..."}]},
    "summary": "...",
    "education": [
      {"id":"edu-1","school":"...","degree":"...","major":"...","start":"...","end":"...","gpa":"...","rank":"...","courses":"...","highlights":["..."]}
    ],
    "experience": [
      {"id":"exp-1","company":"...","title":"...","start":"...","end":"...","location":"...","bullets":["..."]}
    ],
    "projects": [...],
    "campus": [...],
    "awards": [...],
    "skills": [{"id":"...","label":"...","items":["..."]}],
    "languages": [...],
    "publications": [...],
    "interests": ["..."],
    "notes": ["针对这次JD改写了哪些点"],
    "unsupported_claims": ["被砍掉的虚假事实"],
    "mapping": [
      {"map_id":"JD-AGENT","category":"responsibility","text":"...","resume_ids":["exp-1.bullet-1"],"rationale":"..."}
    ],
    "pdf_patches": [
      {"page":1,"block_id":"pdf-block-15","source_text":"必须逐字复制上方对应文本块","tailored_text":"长度保持在原文 90%-110% 的改写文本","map_ids":["JD-AGENT"]}
    ]
  }
}
\`\`\`

请只返回上述 JSON，所有 id 字段必须复用候选人资料中已有的 id；如要新增 bullet，请使用 \`<exp-id>.bullet-<index>\` 命名。${s.length?`pdf_patches 必须从上方文本块中选择至少 ${Math.min(3,s.length)} 个，并逐字复制 page、block_id、source_text。`:"pdf_patches 返回空数组。"}`}function ot(e){return e.replace(/"/g,'\\"')}function Zn(e,t){return{basics:{fullName:e.fullName,email:e.email,phone:e.phone,city:e.currentCity,targetRole:e.targetRole,headline:e.selfIntroduction,summary:e.strengths,careerPlan:e.careerPlan,interests:e.hobbies},education:t.education,experience:t.experience,projects:t.projects,campus:t.campus,awards:t.awards,skills:t.skills,languages:t.languages,publications:t.publications,redacted:["idNumber","idType","wechat","qq","address","emergencyContactPhone"]}}function Qn(e,t){const a=(Array.isArray(t)?t:[]).map(i=>({map_id:String(i.map_id||""),category:i.category||"keyword",text:String(i.text||""),resume_ids:Array.isArray(i.resume_ids)?i.resume_ids.map(String):[],rationale:i.rationale?String(i.rationale):void 0})).filter(i=>i.map_id&&i.text),s=i=>a.filter(p=>p.category===i).map(p=>p.text),o=Array.isArray(e.responsibility)&&e.responsibility.length?e.responsibility.map(String):s("responsibility"),r=Array.isArray(e.must_haves)&&e.must_haves.length?e.must_haves.map(String):s("requirement");return{source:"deepseek",responsibility:o,must_haves:r,differentiators:Array.isArray(e.differentiators)?e.differentiators.map(String):[],bonus:Array.isArray(e.bonus)?e.bonus.map(String):[],keywords:Array.isArray(e.keywords)?e.keywords.map(String):[],mappings:a}}function rt(e,t){const a={...e.header,...t.header||{}},s=K(e.education,t.education,i=>({...i,highlights:Array.isArray(i.highlights)?i.highlights:[]})),o=K(e.experience,t.experience,i=>({...i,bullets:Array.isArray(i.bullets)?i.bullets.filter(Boolean):[]})),r=K(e.projects,t.projects,i=>({...i,bullets:Array.isArray(i.bullets)?i.bullets.filter(Boolean):[]}));return{...e,targetRole:t.targetRole||e.targetRole,targetCompany:t.targetCompany||e.targetCompany,header:a,summary:t.summary||e.summary,education:s,experience:o,projects:r,campus:K(e.campus,t.campus,i=>({...i})),awards:K(e.awards,t.awards,i=>({...i})),skills:K(e.skills,t.skills,i=>({...i,items:Array.isArray(i.items)?i.items:[]})),languages:K(e.languages,t.languages,i=>({...i})),publications:K(e.publications,t.publications,i=>({...i})),interests:Array.isArray(t.interests)?t.interests:e.interests}}function K(e,t,a){if(!Array.isArray(t)||t.length===0)return e.map(a);const s=new Map(t.filter(i=>i==null?void 0:i.id).map(i=>[i.id,i])),o=e.map(i=>a({...i,...s.get(i.id)||{}})),r=new Set(e.map(i=>i.id));return t.filter(i=>(i==null?void 0:i.id)&&!r.has(i.id)).forEach(i=>o.push(a(i))),o}function ea(e,t){const a=pt(e),s={...a,targetRole:t.position,targetCompany:t.company,summary:ta(a.summary,t)},o={source:"fallback",responsibility:t.responsibilities,must_haves:t.requirements,differentiators:[],bonus:[],keywords:Ne(t),mappings:na(s,t)};return{context:t,jd:o,resume:s,generatedAt:new Date().toISOString(),notes:["未启用 DeepSeek：当前是按本地规则生成的关键词匹配版。配置 API Key 后会获得更好的定制效果。"],unsupportedClaims:[]}}function ta(e,t){const a=Ne(t).slice(0,3);return e?a.length?`${e.replace(/[。\.]\s*$/,"")}。曾多次涉及${a.join("、")}相关工作。`:e:a.length?`面向 ${t.position} 的候选人，期待加入 ${t.company||"贵公司"}。`:`面向 ${t.position} 的候选人，期待加入 ${t.company||"贵公司"}。`}function Ne(e){const t=new Set(["的","和","与","及","等","在","为","或","是","有","并","以","可","能","会","其他","相关","工作","岗位","职位","负责","具备","熟悉","良好","优先","以上"]),a=[e.position,e.summary||"",...e.responsibilities||[],...e.requirements||[]].join(`
`),s={};return a.replace(/[，。；：、（）()【】《》!??"",.]/g," ").split(/\s+/).forEach(o=>{const r=o.trim();!r||r.length<2||r.length>18||t.has(r)||(s[r]=(s[r]||0)+1)}),Object.entries(s).sort((o,r)=>r[1]-o[1]).slice(0,8).map(([o])=>o)}function na(e,t){const a=[];return Ne(t).forEach((o,r)=>{const i=[];e.experience.forEach(p=>{p.bullets.forEach((h,c)=>{h.includes(o)&&i.push(`${p.id}.bullet-${c}`)})}),e.projects.forEach(p=>{p.bullets.forEach((h,c)=>{h.includes(o)&&i.push(`${p.id}.bullet-${c}`)})}),i.length!==0&&a.push({map_id:`JD-LOCAL-${r+1}`,category:"keyword",text:o,resume_ids:Array.from(new Set(i)),rationale:"按关键词本地匹配"})}),a}function be(e){return e.company||e.position?Ke(e):Ke({...e,sourceUrl:e.sourceUrl||(location==null?void 0:location.href)||""})}function it(e,t){return!!(e&&t&&e===t)}function lt(e,t){return t?!1:/\.(?:docx|txt)$/i.test((e==null?void 0:e.trim())||"")}function aa(e){return e.hasBundle?e.hasSourcePdf?e.sourceLayoutState==="idle"||e.sourceLayoutState==="loading"?{mode:"loading",html:"",error:""}:e.sourceLayoutState==="error"?{mode:"error",html:"",error:e.sourceLayoutError||"原 PDF 版式读取失败，请重试。"}:e.coordinatePreviewError?{mode:"error",html:"",error:e.coordinatePreviewError}:e.coordinatePreviewHtml?{mode:"coordinate",html:e.coordinatePreviewHtml,error:""}:{mode:"error",html:"",error:"原 PDF 已读取，但坐标版预览生成失败，请重试。"}:e.allowFlowPreview?e.flowPreviewHtml?{mode:"flow",html:e.flowPreviewHtml,error:""}:{mode:"error",html:"",error:"DOCX/TXT 简历预览生成失败，请重新生成。"}:{mode:"error",html:"",error:"未找到本次定制对应的原 PDF、DOCX 或 TXT 简历，请重新选择源简历后生成。"}:{mode:"empty",html:"",error:""}}function sa(e){return typeof e=="number"?`${e} 字`:"正在读取"}const oa="context",ra="auto",te=[{id:"reading",label:"读取职位描述",detail:"正在整理岗位职责和任职要求"},{id:"matching",label:"匹配你的经历",detail:"正在寻找可以支撑 JD 的真实经历"},{id:"rewriting",label:"改写简历重点",detail:"只调整表达，不修改事实信息"},{id:"checking",label:"检查定制结果",detail:"正在检查映射关系和内容完整性"}],ia=[{id:"capture",label:"从招聘页一键抓取",hint:"推荐 · 准确率最高"},{id:"existing",label:"从已有岗位选择",hint:"复用已保存的 JD"},{id:"manual",label:"手动填写 JD",hint:"粘贴或敲字即用"}];function la(){var Ie,Ae,Re;const[e,t]=S.useState({...Wt}),[a,s]=S.useState({}),[o,r]=S.useState(),[i,p]=S.useState({}),[h,c]=S.useState([]),[l,m]=S.useState(),[u,x]=S.useState(!1),[y,j]=S.useState("idle"),[N,F]=S.useState(),[g,D]=S.useState(),[$,k]=S.useState(""),[P,E]=S.useState(""),[B,pe]=S.useState("capture"),[H,xt]=S.useState(()=>ca()),[bt,yt]=S.useState(""),[vt,wt]=S.useState(!1),[w,De]=S.useState(),[Me,Y]=S.useState(),[jt,Z]=S.useState("idle"),[ne,Q]=S.useState(),[$t,ue]=S.useState(""),[kt,St]=S.useState(0);S.useEffect(()=>{(async()=>{var _e,Be;const[b,f,v,M,L,T]=await Promise.all([Gt(),Xt(),Vt(),Yt(),Ue(),qe()]),A=L.find(J=>J.id===T)||L[0];t((A==null?void 0:A.profile)||b),s(f),c(v),p(Object.fromEntries(Object.entries(M).map(([J,X])=>[J,{savedAt:X.savedAt,notes:X.notes}])));const R=new URLSearchParams(location.search),I=R.get(oa),se=R.get(ra)==="1",Oe=I?Sa(I):void 0;if(Oe){const J=Oe.context,X=J.jobKey||be(J),He=J.sourceResumeId||(A==null?void 0:A.id),At=ut({...J,jobKey:X,sourceResumeId:He}),ee=L.find(Ot=>Ot.id===He);m(At),De(ee);const V=await We(X),Rt=!!(V&&it(V.context.sourceResumeId,ee==null?void 0:ee.id));V&&Rt?(r(V),k(`已载入历史定制（${ce(V.generatedAt)}）`),D(await Ge(X))):V?(r(void 0),D(void 0),k(""),E(ee?"该岗位的历史定制来自另一份简历，已忽略。请基于当前简历重新生成。":"历史定制绑定的源简历已不存在，已忽略。请重新选择简历并生成。"),se&&F((_e=f.deepseekApiKey)!=null&&_e.trim()?"deepseek":"local")):se&&F((Be=f.deepseekApiKey)!=null&&Be.trim()?"deepseek":"local")}})()},[]),S.useEffect(()=>{var f;if(typeof chrome>"u"||!((f=chrome.storage)!=null&&f.onChanged))return;const b=(v,M)=>{var T,A;if(M!=="local")return;const L=(T=v[Zt])==null?void 0:T.newValue;L&&(s(L),(A=L.deepseekApiKey)!=null&&A.trim()&&(E(""),k("DeepSeek 已配置，可以开始改写简历")))};return chrome.storage.onChanged.addListener(b),()=>chrome.storage.onChanged.removeListener(b)},[]),S.useEffect(()=>{const b=w==null?void 0:w.sourcePdf;if(!b){Y(void 0),Q(void 0),Z("idle"),ue("");return}const f=w.id;let v=!1;return Y(void 0),Q(f),Z("loading"),ue(""),Ye(ye(b.base64).buffer).then(async M=>{if(!v){if(!M.pages.length||M.pages.some(L=>!L.imageDataUrl))throw new Error("原 PDF 页面渲染不完整，无法生成版式预览");try{await Xe(f,{layoutStatus:"ready",pageCount:M.pages.length,characterCount:M.characterCount})}catch(L){console.warn("[JobKoI] PDF 版式元数据同步失败",L)}v||(Y(M),Q(f),Z("ready"))}}).catch(M=>{if(v)return;Y(void 0),Q(f),Z("error");const L=M instanceof Error?M.message:"未知 PDF 读取错误";ue(L),Xe(f,{layoutStatus:"failed"}),console.error("[JobKoI] 原 PDF 版式读取失败",M)}),()=>{v=!0}},[w==null?void 0:w.id,(Ie=w==null?void 0:w.sourcePdf)==null?void 0:Ie.base64,kt]);const he=S.useMemo(()=>Object.entries(i),[i]),me=!!(w!=null&&w.sourcePdf),fe=!!(w&&lt(w.sourceFileName,me)),W=ne===(w==null?void 0:w.id)?Me:void 0,Et=me&&ne!==(w==null?void 0:w.id)?"loading":jt,Pt=ne===(w==null?void 0:w.id)?$t:"",Nt=S.useMemo(()=>!o||!fe?"":Fn({resume:o.resume,jd:o.jd,showJdSidebar:!1,variant:"source-aligned",sourceProfile:w==null?void 0:w.profile,accentColor:"#202421",pageSize:"a4"}),[fe,o,w==null?void 0:w.profile]),ge=S.useMemo(()=>{var b;if(!o||!W||!(w!=null&&w.profile))return{html:"",error:"",overrideCount:0};try{const f=vn({layout:W,resume:o.resume,sourceProfile:w.profile,jd:o.jd,pdfPatches:o.pdfPatches}),v=Number(((b=f.match(/name="tailored-override-count" content="(\d+)"/))==null?void 0:b[1])||0);return{html:f,error:"",overrideCount:v}}catch(f){const v=f instanceof Error?f.message:"未知坐标预览错误";return console.error("[JobKoI] PDF 坐标复刻失败",f),{html:"",error:`原 PDF 坐标预览生成失败：${v}`,overrideCount:0}}},[o,W,w==null?void 0:w.profile]),Ce=aa({hasBundle:!!o,hasSourcePdf:me,allowFlowPreview:fe,sourceLayoutState:Et,sourceLayoutError:Pt,coordinatePreviewHtml:ge.html,coordinatePreviewError:ge.error,flowPreviewHtml:Nt}),ae=Ce.html,G=l?o?"jd-bundled":"jd-ready":"pending-empty",xe=async b=>{if(!l)return;x(!0),E(""),j("reading");const f=[window.setTimeout(()=>j("matching"),650),window.setTimeout(()=>j("rewriting"),1400)];try{const[v,M]=await Promise.all([Ue(),qe()]),L=l.sourceResumeId?v.find(I=>I.id===l.sourceResumeId):void 0;if(l.sourceResumeId&&!L)throw new Error("这份定制记录绑定的原 PDF 已不存在，请从简历库重新选择母版");const T=L||v.find(I=>I.id===M)||v[0];if(!T)throw new Error("没有找到可用于定制的源简历，请返回简历库重新选择");if(!T.sourcePdf&&!lt(T.sourceFileName,!1))throw new Error("当前简历缺少可用的 PDF、DOCX 或 TXT 原文件，请返回简历库重新导入后再生成");De(T);const A=l.sourceResumeId===T.id?l:{...l,sourceResumeId:T.id};A!==l&&m(A);let R;if(b==="deepseek"){if(!a.deepseekApiKey)throw new Error("未配置 DeepSeek API Key，请先在设置中填写");let I=ne===T.id?Me:void 0;!I&&T.sourcePdf&&(I=await Ye(ye(T.sourcePdf.base64).buffer),Y(I),Q(T.id),Z("ready"));const se=bn(I);R=await Vn(T.profile,A,a,se)}else R=ea(T.profile,A);j("checking"),await new Promise(I=>window.setTimeout(I,260)),r(R),await Qt({jobKey:R.context.jobKey,bundle:R,savedAt:new Date().toISOString(),notes:R.notes}),p(I=>({...I,[R.context.jobKey]:{savedAt:new Date().toISOString(),notes:R.notes}})),j("ready"),k(b==="deepseek"?"DeepSeek 已生成定制简历":"本地已生成定制简历")}catch(v){j("error"),E(v instanceof Error?v.message:"生成失败")}finally{f.forEach(v=>window.clearTimeout(v)),x(!1)}};S.useEffect(()=>{if(!N||!l||o||u)return;const b=N;F(void 0),xe(b)},[N,l,o,u,a.deepseekApiKey]);const Te=()=>{if(!ae)return;const b=`${(o==null?void 0:o.context.company)||"简历"}-${(o==null?void 0:o.context.position)||"tailored"}`.replace(/[\\/:*?"<>|]/g,"-"),f=URL.createObjectURL(new Blob([ae],{type:"text/html;charset=utf-8"}));Object.assign(document.createElement("a"),{href:f,download:`${b}.html`}).click(),setTimeout(()=>URL.revokeObjectURL(f),1e3)},Fe=()=>{if(!ae)return;const b=new Blob([ae],{type:"text/html;charset=utf-8"}),f=URL.createObjectURL(b);window.open(f,"_blank","noopener,noreferrer")},Le=async b=>{confirm("删除这条定制记录？已保存的 PDF 也会一并删除。")&&(await en(b),await Ve(b),p(f=>{const v={...f};return delete v[b],v}),(o==null?void 0:o.context.jobKey)===b&&(r(void 0),m(void 0),D(void 0),j("idle")),k("已删除定制记录"))},Dt=async b=>{var v;const f=(v=b.target.files)==null?void 0:v[0];if(b.target.value="",!!f){if(!l){E("请先选择要投递的岗位，再上传 PDF 简历。");return}if(f.type!=="application/pdf"){E("仅支持 PDF 格式");return}if(f.size>8*1024*1024){E("PDF 不能超过 8MB（chrome.storage.local 单条建议 < 8MB）");return}x(!0);try{const M=await f.arrayBuffer(),L=Na(M),T={jobKey:l.jobKey,fileName:f.name,size:f.size,uploadedAt:new Date().toISOString(),base64:L};await tn(l.jobKey,T),D(T),k(`已保存 PDF · ${f.name}（${gt(f.size)}）`)}catch(M){E(M instanceof Error?M.message:"上传失败")}finally{x(!1)}}},Mt=()=>{if(!g)return;const b=ye(g.base64),f=new Blob([b],{type:"application/pdf"}),v=URL.createObjectURL(f);Object.assign(document.createElement("a"),{href:v,download:g.fileName}).click(),setTimeout(()=>URL.revokeObjectURL(v),1e3)},Ct=b=>{const f=$a(b),v={...f,jobKey:be(f)};r(void 0),m(v),j("idle"),E(""),k(`已载入岗位：${v.company} · ${v.position}`)},Tt=()=>{if(!H.position.trim()){E("请先填写岗位名称");return}const f={jobKey:"",company:H.company.trim()||"手动填写",position:H.position.trim(),city:H.city.trim()||void 0,summary:H.summary.trim()||void 0,responsibilities:ct(H.responsibilities),requirements:ct(H.requirements),sourceUrl:""},v={...f,jobKey:be(f)};r(void 0),m(v),j("idle"),E(""),k(`已填入岗位：${v.company} · ${v.position}`)},Ft=()=>{if(typeof chrome>"u"||!chrome.tabs){E("当前环境无法打开招聘页签");return}chrome.tabs.query({active:!0,currentWindow:!0}).then(([b])=>{var f;b!=null&&b.id&&((f=b.url)!=null&&f.startsWith("http"))?k("打开 JobKoI 浮窗 → 点「为这个岗位定制简历」"):E("请先打开一个招聘网页，再从这里开始定制")}).catch(()=>{})},Lt=()=>{var f,v;const b=typeof chrome<"u"&&((f=chrome.runtime)!=null&&f.getURL)?chrome.runtime.getURL("dashboard.html"):new URL("dashboard.html",window.location.href).href;if(typeof chrome<"u"&&((v=chrome.tabs)!=null&&v.create)){chrome.tabs.create({url:b});return}window.open(b,"_blank","noopener,noreferrer")},zt=()=>{var f,v;const b=typeof chrome<"u"&&((f=chrome.runtime)!=null&&f.getURL)?chrome.runtime.getURL("dashboard.html?view=settings"):new URL("dashboard.html?view=settings",window.location.href).href;if(typeof chrome<"u"&&((v=chrome.tabs)!=null&&v.create)){chrome.tabs.create({url:b}).catch(()=>{window.open(b,"_blank","noopener,noreferrer")});return}window.open(b,"_blank","noopener,noreferrer")},It=()=>{var f,v;const b=typeof chrome<"u"&&((f=chrome.runtime)!=null&&f.getURL)?chrome.runtime.getURL("resume.html"):new URL("resume.html",window.location.href).href;if(typeof chrome<"u"&&((v=chrome.tabs)!=null&&v.create)){chrome.tabs.create({url:b});return}window.open(b,"_blank","noopener,noreferrer")},ze=!!((Ae=a.deepseekApiKey)!=null&&Ae.trim());return n.jsxs("div",{className:"review-shell",children:[n.jsx(da,{phase:G,pending:l,bundle:o,busy:u,generationStage:y,hasApiKey:ze,onGenerate:xe,onOpenSettings:zt,onOpenInNewTab:Fe,onDownloadHtml:Te,onClose:()=>window.close()}),(P||$)&&n.jsx("div",{className:"review-shell",style:{padding:"10px 18px 0"},children:n.jsx("div",{className:`review-status ${P?"review-status-error":"review-status-ok"}`,style:{flex:"none"},children:P?n.jsxs(n.Fragment,{children:[n.jsx(ht,{size:12})," ",P]}):n.jsxs(n.Fragment,{children:[n.jsx(re,{size:12})," ",$]})})}),G==="pending-empty"&&n.jsx(pa,{profile:e,jobs:h,storedJobs:he,intakeTab:B,setIntakeTab:pe,manualDraft:H,setManualDraft:xt,pickedJobId:bt,setPickedJobId:yt,profileStatusOpen:vt,setProfileStatusOpen:wt,onStartFromExistingJob:Ct,onStartFromManualDraft:Tt,onOpenCaptureTab:Ft,onOpenResumeManager:It,onOpenDashboard:Lt,onDeleteEntry:Le}),(G==="jd-ready"||G==="jd-bundled")&&l&&n.jsx(ba,{phase:G,pending:l,bundle:o,preview:Ce,sourcePdfName:(Re=w==null?void 0:w.sourcePdf)==null?void 0:Re.fileName,sourceCharacterCount:W==null?void 0:W.characterCount,overrideCount:ge.overrideCount,pdfSnapshot:g,busy:u,generationStage:y,hasApiKey:ze,onGenerate:xe,onOpenInNewTab:Fe,onDownloadHtml:Te,onPdfUpload:Dt,onDownloadStoredPdf:Mt,onRetrySourceLayout:()=>St(b=>b+1),onRemovePdf:async()=>{await Ve(l.jobKey),D(void 0),k("已删除保存的 PDF")}}),G!=="pending-empty"&&he.length>0&&n.jsx(ja,{storedJobs:he,onLoad:async b=>{const f=await We(b);if(f){if(!it(f.context.sourceResumeId,w==null?void 0:w.id)){k(""),E("这份历史定制来自另一份简历，已忽略。请基于当前简历重新生成。");return}r(f),m(f.context),D(await Ge(b)),E(""),k(`已载入历史定制：${f.context.company} · ${f.context.position}`)}},onDelete:Le})]})}function da({phase:e,pending:t,bundle:a,busy:s,generationStage:o,hasApiKey:r,onOpenSettings:i,onGenerate:p,onOpenInNewTab:h,onDownloadHtml:c,onClose:l}){const m=t?`${t.company} · ${t.position}`:"未传入岗位上下文",u=t?"toolbar-job is-set":"toolbar-job",x=te.find(y=>y.id===o);return n.jsxs("header",{className:"review-toolbar",children:[n.jsxs("div",{className:"toolbar-title",children:[n.jsx("strong",{children:"JD × 简历对靶审阅"}),n.jsx("span",{className:u,children:m})]}),n.jsxs("div",{className:"toolbar-actions",children:[s&&n.jsxs("div",{className:"generation-toolbar-status","aria-live":"polite",children:[n.jsx(q,{className:"spin",size:14}),n.jsxs("span",{children:[n.jsx("strong",{children:"正在生成定制简历"}),n.jsx("small",{children:(x==null?void 0:x.label)||"正在处理"})]})]}),e==="pending-empty"&&n.jsxs("button",{type:"button",className:"ghost",onClick:l,children:[n.jsx(Je,{size:14})," 关闭"]}),(e==="jd-ready"||e==="jd-bundled")&&n.jsxs(n.Fragment,{children:[n.jsxs("div",{className:"primary-stack",children:[n.jsxs("button",{type:"button",className:"primary",disabled:s,onClick:()=>r?p("deepseek"):i(),title:r?"用 DeepSeek 改写简历":"先在设置中填写 DeepSeek API Key",children:[s?n.jsx(q,{className:"spin",size:14}):n.jsx(ie,{size:14}),r?"DeepSeek 改写":"配置 DeepSeek"]}),!r&&n.jsxs("span",{className:"btn-hint is-status",children:[n.jsx(Kt,{size:12})," 未配置 API Key"]})]}),n.jsx("div",{className:"action-cluster",children:n.jsxs("button",{type:"button",disabled:s,onClick:()=>p("local"),title:"无需 API Key，按本地关键词匹配生成",children:[n.jsx($e,{size:14})," 本地兜底"]})}),a&&n.jsxs("div",{className:"action-cluster",children:[n.jsxs("button",{type:"button",onClick:h,children:[n.jsx(le,{size:14})," 新标签"]}),n.jsxs("button",{type:"button",onClick:c,children:[n.jsx(ke,{size:14})," 保存 HTML"]})]}),n.jsxs("button",{type:"button",className:"ghost",onClick:l,children:[n.jsx(Je,{size:14})," 关闭"]})]})]}),n.jsxs("div",{className:"review-status",children:[e==="pending-empty"&&"先把岗位上下文传进来，才能开始定制。下面三个入口任选其一。",e==="jd-ready"&&(r?"已抓到岗位。点「DeepSeek 改写」一键产出定制版，没有 API Key 可用「本地兜底」。":"已抓到岗位。先在设置里填 DeepSeek API Key，或先用「本地兜底」预览结构。"),e==="jd-bundled"&&"点左侧 JD 卡片可高亮右侧简历对应 bullet；打 PDF 前记得先点「保存 HTML」。"]})]})}function ca(){return{company:"",position:"",city:"",summary:"",responsibilities:"",requirements:""}}function pa({profile:e,jobs:t,storedJobs:a,intakeTab:s,setIntakeTab:o,manualDraft:r,setManualDraft:i,pickedJobId:p,setPickedJobId:h,profileStatusOpen:c,setProfileStatusOpen:l,onStartFromExistingJob:m,onStartFromManualDraft:u,onOpenCaptureTab:x,onOpenResumeManager:y,onOpenDashboard:j,onDeleteEntry:N}){const F=!!(e.fullName||e.phone||e.email||e.education.length||e.experiences.length);return n.jsxs("div",{className:"empty-shell",children:[n.jsxs("div",{className:"empty-hero",children:[n.jsx("div",{className:"hero-glyph",children:n.jsx(ie,{size:26})}),n.jsxs("div",{children:[n.jsx("h1",{children:"先把岗位传进来"}),n.jsx("p",{children:"「对靶审阅」需要一份具体的 JD 才能定制。下面三种方式都能进入下一步：让 JobKoI 浮窗抓当前页面、从已保存的岗位里挑一个，或当场手填一份。"})]})]}),n.jsxs("section",{className:"intake-tabs","aria-label":"传入岗位的三种方式",children:[n.jsx("header",{children:ia.map(g=>n.jsxs("button",{type:"button",className:s===g.id?"active":"",onClick:()=>o(g.id),children:[g.label,n.jsx("small",{style:{fontWeight:400,color:"var(--muted)",fontSize:11},children:g.hint})]},g.id))}),n.jsxs("div",{className:"intake-pane",children:[s==="capture"&&n.jsx(ua,{onOpenCaptureTab:x,onOpenDashboard:j}),s==="existing"&&n.jsx(ha,{jobs:t,pickedJobId:p,setPickedJobId:h,onPick:m}),s==="manual"&&n.jsx(ma,{draft:r,setDraft:i,onSubmit:u})]})]}),n.jsx(fa,{profile:e,hasProfile:F,open:c,setOpen:l,onOpenResumeManager:y}),a.length>0&&n.jsx(xa,{title:"历史定制",subtitle:`${a.length} 个版本 · 仅本机`,storedJobs:a,onLoad:async g=>{const D=await Ut(()=>import("./storage-DoBTTLH_.js").then($=>$.ac),[]).then($=>$.getTailoredResume(g));D&&(window.location.href=`tailor.html?context=${Pa({jobKey:g,context:D.context})}`)},onDelete:N})]})}function ua({onOpenCaptureTab:e,onOpenDashboard:t}){return n.jsxs(n.Fragment,{children:[n.jsx("h2",{children:"从招聘页一键抓取"}),n.jsx("p",{className:"pane-lead",children:"先打开任意招聘网页，让 JobKoI 浮窗识别岗位，然后回到这里。"}),n.jsxs("div",{className:"capture-guide",children:[n.jsxs("div",{className:"capture-step",children:[n.jsx("span",{className:"step-mark",children:"1"}),n.jsx("strong",{children:"打开招聘网页"}),n.jsx("span",{children:"把 JobKoI 扩展固定到工具栏，并在招聘详情页面停留几秒。"})]}),n.jsxs("div",{className:"capture-step",children:[n.jsx("span",{className:"step-mark",children:"2"}),n.jsx("strong",{children:"浮窗里点「为这个岗位定制简历」"}),n.jsx("span",{children:"JobKoI 会自动抓岗位信息，并把上下文传到这个页面。"})]}),n.jsxs("div",{className:"capture-step",children:[n.jsx("span",{className:"step-mark",children:"3"}),n.jsx("strong",{children:"DeepSeek 改写 → 导出 PDF"}),n.jsx("span",{children:"首次进入后，配置 API Key → 生成定制 → 打印为 PDF。"})]})]}),n.jsx("div",{className:"manual-form",style:{marginTop:18},children:n.jsxs("div",{className:"manual-actions",style:{gridColumn:"1 / -1",marginTop:0},children:[n.jsx("span",{className:"lead",children:"提示：首次使用建议先把 API Key 配置好，避免定制完才发现要走设置流程。"}),n.jsxs("span",{className:"actions",children:[n.jsxs("button",{type:"button",onClick:e,children:[n.jsx(sn,{size:14})," 提醒浮窗已就绪"]}),n.jsxs("button",{type:"button",className:"primary",onClick:t,children:[n.jsx(an,{size:14})," 打开工作台"]})]})]})})]})}function ha({jobs:e,pickedJobId:t,setPickedJobId:a,onPick:s}){const o=S.useMemo(()=>e.filter(r=>r.position).sort((r,i)=>i.updatedAt.localeCompare(r.updatedAt)),[e]);return n.jsxs(n.Fragment,{children:[n.jsx("h2",{children:"从已有岗位选择"}),n.jsx("p",{className:"pane-lead",children:"直接复用 JobKoI 已经保存的岗位信息。岗位里的 JD 摘要、职责、要求都会被一并带入。"}),o.length===0?n.jsx("div",{className:"jobs-picker-list",children:n.jsx("div",{className:"empty-hint",children:"JobKoI 目前还没有岗位记录。请先用「从招聘页一键抓取」或「手动填写 JD」。"})}):n.jsxs(n.Fragment,{children:[n.jsx("div",{className:"jobs-picker-list",children:o.map(r=>{const i=r.id===t;return n.jsxs("button",{type:"button",onClick:()=>a(r.id),disabled:i,"aria-pressed":i,children:[n.jsxs("span",{children:[n.jsx("strong",{children:r.position}),n.jsxs("small",{children:[r.company,r.city?` · ${r.city}`:"",r.deadline?` · 截止 ${r.deadline}`:""]})]}),n.jsxs("span",{className:"job-meta",children:[n.jsx("span",{children:ce(r.updatedAt)}),i&&n.jsx(re,{size:13})]})]},r.id)})}),n.jsx("div",{className:"manual-form",style:{marginTop:18},children:n.jsxs("div",{className:"manual-actions",style:{gridColumn:"1 / -1",marginTop:0},children:[n.jsx("span",{className:"lead",children:t?"选中的岗位会作为这一次的定制上下文":"先在上面挑一个岗位，再点「使用此岗位」"}),n.jsx("span",{className:"actions",children:n.jsxs("button",{type:"button",className:"primary",disabled:!t,onClick:()=>{const r=o.find(i=>i.id===t);r&&s(r)},children:[n.jsx(Se,{size:14})," 使用此岗位"]})})]})})]})]})}function ma({draft:e,setDraft:t,onSubmit:a}){const s=!!e.position.trim();return n.jsxs(n.Fragment,{children:[n.jsx("h2",{children:"手动填写 JD"}),n.jsx("p",{className:"pane-lead",children:"没有合适的页面或岗位在手？把 JD 关键信息粘进下面，至少岗位名必填。"}),n.jsxs("div",{className:"manual-form",children:[n.jsxs("label",{children:[n.jsx("span",{children:"岗位名称 *"}),n.jsx("input",{type:"text",value:e.position,onChange:o=>t({...e,position:o.target.value}),placeholder:"例如：算法工程师 · 推荐方向"})]}),n.jsxs("label",{children:[n.jsx("span",{children:"公司"}),n.jsx("input",{type:"text",value:e.company,onChange:o=>t({...e,company:o.target.value}),placeholder:"例如：字节跳动"})]}),n.jsxs("label",{children:[n.jsx("span",{children:"城市"}),n.jsx("input",{type:"text",value:e.city,onChange:o=>t({...e,city:o.target.value}),placeholder:"例如：北京"})]}),n.jsxs("label",{children:[n.jsx("span",{children:"岗位摘要"}),n.jsx("input",{type:"text",value:e.summary,onChange:o=>t({...e,summary:o.target.value}),placeholder:"一句话概括 JD 的方向"})]}),n.jsxs("label",{className:"full",children:[n.jsx("span",{children:"工作职责（每行一条）"}),n.jsx("textarea",{rows:4,value:e.responsibilities,onChange:o=>t({...e,responsibilities:o.target.value}),placeholder:`负责推荐系统核心算法迭代
建设 AB 实验平台
协同上下游工程团队落地模型`})]}),n.jsxs("label",{className:"full",children:[n.jsx("span",{children:"岗位要求（每行一条）"}),n.jsx("textarea",{rows:4,value:e.requirements,onChange:o=>t({...e,requirements:o.target.value}),placeholder:`硕士及以上 / 机器学习方向
熟悉 TensorFlow / PyTorch
有大规模分布式训练经验优先`})]}),n.jsxs("div",{className:"manual-actions",children:[n.jsx("span",{className:"lead",children:"提交后会按本地规则生成一版，后续可以再切到 DeepSeek 改写。"}),n.jsx("span",{className:"actions",children:n.jsxs("button",{type:"button",className:"primary",disabled:!s,onClick:a,children:[n.jsx($e,{size:14})," 开始定制"]})})]})]})]})}function fa({profile:e,hasProfile:t,open:a,setOpen:s,onOpenResumeManager:o}){return n.jsxs("section",{className:"profile-status","aria-label":"个人资料状态",children:[n.jsx("div",{className:"ps-mark",children:n.jsx(_t,{size:18})}),n.jsxs("div",{className:"ps-copy",children:[n.jsx("strong",{children:t?"个人资料已就绪":"首次使用 · 还没有个人资料"}),n.jsx("small",{children:t?`${e.fullName||"未填姓名"} · ${e.education.length} 段教育 · ${e.experiences.length} 段经历 · ${e.projects.length} 个项目`:"先在简历中心录入姓名、学历、经历和项目，定制出来的简历才会有素材。"})]}),n.jsx("button",{type:"button",onClick:()=>s(!a),children:a?n.jsxs(n.Fragment,{children:[n.jsx(nn,{size:14})," 收起"]}):n.jsxs(n.Fragment,{children:[n.jsx(Bt,{size:14})," ",t?"查看字段":"补全资料"]})}),a&&n.jsx(ga,{profile:e,onOpenResumeManager:o})]})}function ga({profile:e,onOpenResumeManager:t}){const a=[["姓名",e.fullName||"—"],["电话",e.phone||"—"],["邮箱",e.email||"—"],["现居地",e.currentCity||"—"],["意向岗位",e.targetRole||"—"],["教育段数",`${e.education.length} 段`],["实习 / 工作",`${e.experiences.length} 段`],["项目经历",`${e.projects.length} 段`]];return n.jsxs("div",{style:{flexBasis:"100%",marginTop:12,paddingTop:12,borderTop:"1px dashed var(--line)",display:"grid",gridTemplateColumns:"repeat(auto-fill, minmax(160px, 1fr))",gap:"8px 16px"},children:[a.map(([s,o])=>n.jsxs("div",{style:{fontSize:12.5},children:[n.jsx("div",{style:{color:"var(--muted)"},children:s}),n.jsx("div",{style:{color:"var(--ink)",marginTop:2},children:o})]},s)),n.jsx("div",{style:{gridColumn:"1 / -1",display:"flex",justifyContent:"flex-end"},children:n.jsxs("button",{type:"button",onClick:t,style:{border:"1px solid var(--blue)",color:"var(--blue)",background:"#fff",borderRadius:8,padding:"6px 12px",font:"inherit",fontSize:12.5,cursor:"pointer",display:"inline-flex",alignItems:"center",gap:5},children:[n.jsx(je,{size:13})," 打开简历中心"]})})]})}function xa({title:e,subtitle:t,storedJobs:a,onLoad:s,onDelete:o}){return n.jsxs("section",{className:"intake-archive","aria-label":e,children:[n.jsxs("header",{children:[n.jsx("strong",{children:e}),n.jsx("small",{children:t})]}),n.jsx("ul",{children:a.map(([r,i])=>n.jsxs("li",{children:[n.jsxs("span",{className:"meta",children:[n.jsx("strong",{children:r.replace(/^tailor_/,"")}),n.jsxs("small",{children:["保存于 ",ce(i.savedAt)]})]}),n.jsxs("span",{className:"row-actions",children:[n.jsxs("button",{type:"button",onClick:()=>s(r),children:[n.jsx(Se,{size:13})," 载入"]}),n.jsxs("button",{type:"button",className:"danger",onClick:()=>o(r),children:[n.jsx(we,{size:13})," 删除"]})]})]},r))})]})}function ba({phase:e,pending:t,bundle:a,preview:s,sourcePdfName:o,sourceCharacterCount:r,overrideCount:i,pdfSnapshot:p,busy:h,generationStage:c,hasApiKey:l,onGenerate:m,onOpenInNewTab:u,onDownloadHtml:x,onPdfUpload:y,onDownloadStoredPdf:j,onRetrySourceLayout:N,onRemovePdf:F}){var B;const g=S.useRef(null),[D,$]=S.useState(!1),k=s.html;S.useEffect(()=>{$(!1)},[k]);const P=()=>{$(!0)},E=((B=t.rawExcerpt)==null?void 0:B.trim())||[t.summary,t.responsibilities.length?`岗位职责
${t.responsibilities.join(`
`)}`:"",t.requirements.length?`任职要求
${t.requirements.join(`
`)}`:""].filter(Boolean).join(`

`);return n.jsxs("div",{className:"review-grid",children:[a&&s.mode==="coordinate"&&n.jsx(ya,{bundle:a,sourcePdfName:o,sourceCharacterCount:r,overrideCount:i,onOpenPreview:u,onDownloadHtml:x}),n.jsxs("section",{className:"panel jd-panel","aria-label":"原始职位描述",children:[n.jsxs("div",{className:"panel-head",children:[n.jsx("strong",{children:t.position||"职位描述 / JD"}),n.jsxs("small",{children:[t.company||"未填写公司"," · ",t.city||"未填写城市"," · ",ka(t.sourceUrl)||"手动传入"]})]}),n.jsxs("div",{className:"jd-scroll",children:[n.jsxs("div",{className:"jd-original-meta",children:[n.jsxs("div",{children:[n.jsx("small",{children:"公司"}),n.jsx("strong",{children:t.company||"未填写公司"})]}),n.jsxs("div",{children:[n.jsx("small",{children:"岗位"}),n.jsx("strong",{children:t.position||"未填写岗位"})]}),t.city&&n.jsxs("div",{children:[n.jsx("small",{children:"地点"}),n.jsx("strong",{children:t.city})]})]}),n.jsxs("article",{className:"jd-original-copy",children:[n.jsx("h2",{children:"岗位 JD"}),n.jsx("div",{children:E||"未读取到岗位原文，请回到招聘页面重新识别。"})]})]})]}),n.jsxs("section",{className:"panel resume-panel","aria-label":"可编辑简历与映射标注",children:[n.jsxs("div",{className:"panel-head",children:[n.jsx("div",{className:"resume-panel-title",children:n.jsx("strong",{children:s.mode==="coordinate"?"原 PDF 高保真编辑":s.mode==="flow"?"兼容编辑预览":s.mode==="loading"?"正在读取原 PDF 版式":s.mode==="error"?"简历预览不可用":"定制简历预览"})}),n.jsx("small",{children:a?n.jsxs("span",{style:{display:"inline-flex",gap:6,alignItems:"center"},children:[n.jsx("span",{className:`bundle-badge ${a.jd.source==="fallback"?"local":""}`,children:a.jd.source==="deepseek"?"DeepSeek 定制":"本地兜底"}),n.jsxs("span",{children:["生成于 ",new Date(a.generatedAt).toLocaleString("zh-CN")]})]}):"尚未生成定制简历"})]}),n.jsx("div",{className:"resume-scroll",children:h&&c!=="idle"&&c!=="error"?n.jsx(dt,{stage:c,pending:t}):s.mode==="loading"?n.jsxs("div",{className:"resume-preview-loading","aria-live":"polite",children:[n.jsx(q,{className:"spin",size:18}),n.jsx("span",{children:"正在读取原 PDF 并按原版式生成预览…"})]}):s.mode==="error"?n.jsxs("div",{className:"resume-empty-state",role:"alert",children:[n.jsx(ht,{size:20}),n.jsx("strong",{children:o?"原 PDF 版式读取失败":"简历预览不可用"}),n.jsx("span",{children:s.error}),o&&n.jsxs(n.Fragment,{children:[n.jsxs("button",{type:"button",onClick:N,children:[n.jsx(q,{size:14})," 重试读取原 PDF"]}),n.jsx("small",{children:"请先重试；若仍失败，请回到简历库重新导入原始 PDF 后再生成。"})]})]}):k&&a?n.jsxs("div",{className:`resume-stage ${D?"is-loaded":"is-loading"}`,children:[n.jsx("iframe",{ref:g,title:"定制简历预览",className:"resume-iframe",srcDoc:k,sandbox:"allow-same-origin allow-scripts allow-forms allow-downloads",onLoad:P}),!D&&n.jsxs("div",{className:"resume-preview-loading","aria-live":"polite",children:[n.jsx(q,{className:"spin",size:18}),n.jsx("span",{children:"正在打开简历预览…"})]})]}):c!=="idle"&&c!=="error"?n.jsx(dt,{stage:c,pending:t}):n.jsx(va,{busy:h,hasApiKey:l,onGenerate:m,onOpenInNewTab:u,onDownloadHtml:x})}),n.jsx("div",{className:"resume-foot",children:n.jsx(wa,{pending:t,pdfSnapshot:p,busy:h,hasBundle:!!a,onOpenPreview:u,onUpload:y,onDownload:j,onRemove:async()=>{await F()}})})]})]})}function ya({bundle:e,sourcePdfName:t,sourceCharacterCount:a,overrideCount:s,onOpenPreview:o,onDownloadHtml:r}){var i;return n.jsxs("section",{className:"tailor-result-banner","aria-live":"polite",children:[n.jsxs("div",{className:"tailor-result-copy",children:[n.jsx("span",{className:"tailor-result-mark",children:n.jsx(re,{size:18})}),n.jsxs("div",{children:[n.jsx("strong",{children:s>0?"原 PDF 版式定制已生成":"定制文案尚未写入原 PDF"}),n.jsx("small",{children:s>0?`${e.context.company||"当前岗位"} · ${e.context.position} · 已按原坐标替换文本`:"当前预览仍是母版原文，请重新生成；系统不会把零替换结果标记为成功。"})]})]}),n.jsx("div",{className:"tailor-result-stats",children:n.jsxs("span",{title:t,children:[t||"原 PDF"," · ",sa(a)," · DeepSeek 改写 ",((i=e.changeSummary)==null?void 0:i.modelChanges)??"—"," 处 · PDF 落版 ",s," 处"]})}),n.jsxs("div",{className:"tailor-result-actions",children:[n.jsxs("button",{type:"button",className:"primary",onClick:o,children:[n.jsx(le,{size:14})," 打开预览并保存 PDF"]}),n.jsxs("button",{type:"button",onClick:r,children:[n.jsx(ke,{size:14})," 下载 HTML"]})]})]})}function dt({stage:e,pending:t}){const a=te.findIndex(o=>o.id===e),s=te[a]||te[0];return n.jsxs("div",{className:"generation-progress","aria-live":"polite",children:[n.jsx("div",{className:"generation-progress-mark",children:n.jsx(ie,{size:22})}),n.jsx("h2",{children:"正在生成岗位定制简历"}),n.jsxs("p",{children:[t.company||"当前公司"," · ",t.position||"目标岗位"]}),n.jsx("div",{className:"generation-steps",children:te.map((o,r)=>{const i=r<a?"complete":r===a?"active":"pending";return n.jsxs("div",{className:`generation-step ${i}`,children:[n.jsx("span",{children:i==="complete"?n.jsx(re,{size:12}):r+1}),n.jsx("strong",{children:o.label})]},o.id)})}),n.jsxs("div",{className:"generation-progress-detail",children:[n.jsx(q,{className:"spin",size:14}),n.jsx("span",{children:s.detail})]})]})}function va({busy:e,hasApiKey:t,onGenerate:a,onOpenInNewTab:s,onDownloadHtml:o}){return n.jsxs("div",{className:"resume-pending",children:[n.jsx("div",{className:"pending-glyph",children:n.jsx(je,{size:22})}),n.jsx("h2",{children:"等待生成第一版定制简历"}),n.jsxs("p",{children:[t?"已检测到 DeepSeek 配置，点下方按钮即可基于左侧 JD 改写你的简历。":"尚未配置 DeepSeek API Key。先点「本地兜底」看结构，再去设置里填 Key 用 DeepSeek。"," ","后续编辑、再生成、打印 PDF 都在同一页面。"]}),n.jsxs("div",{className:"pending-actions",children:[n.jsxs("button",{type:"button",className:"primary",disabled:e||!t,onClick:()=>a("deepseek"),children:[e?n.jsx(q,{className:"spin",size:14}):n.jsx(ie,{size:14}),"DeepSeek 改写"]}),n.jsxs("button",{type:"button",disabled:e,onClick:()=>a("local"),children:[n.jsx($e,{size:14})," 本地兜底"]}),n.jsxs("button",{type:"button",onClick:s,children:[n.jsx(le,{size:14})," 新标签预览"]}),n.jsxs("button",{type:"button",onClick:o,children:[n.jsx(ke,{size:14})," 保存 HTML"]})]})]})}function wa({pending:e,pdfSnapshot:t,busy:a,hasBundle:s,onOpenPreview:o,onUpload:r,onDownload:i,onRemove:p}){return n.jsxs("div",{className:"pdf-manager",children:[n.jsxs("div",{className:"pdf-manager-copy",children:[n.jsx("strong",{children:"投递 PDF（可选）"}),n.jsx("small",{children:t?`已保存：${t.fileName} · ${gt(t.size)}`:e&&s?"原 PDF 母版已用于定制版式；打开预览可保存最终投递 PDF。":e?"当前简历库中的原 PDF 会作为定制母版；生成后可在这里保存投递稿。":"先选定岗位，再生成基于原 PDF 版式的投递稿。"})]}),n.jsxs("div",{className:"pdf-manager-actions",children:[s&&!t&&n.jsxs("button",{type:"button",className:"pdf-preview-action",onClick:o,children:[n.jsx(le,{size:14})," 打开预览并保存 PDF"]}),n.jsxs("label",{className:`pdf-upload ${!e||a||!s?"is-disabled":""}`,children:[n.jsx("input",{type:"file",accept:"application/pdf",onChange:r,disabled:!e||a||!s}),n.jsx(qt,{size:14}),n.jsx("span",{children:t?"替换 PDF":s?"上传自定义 PDF":"上传 PDF"})]}),t&&n.jsxs(n.Fragment,{children:[n.jsxs("button",{type:"button",onClick:i,children:[n.jsx(je,{size:14})," 下载已保存 PDF"]}),n.jsxs("button",{type:"button",className:"pdf-remove",onClick:()=>void p(),children:[n.jsx(we,{size:14})," 删除"]})]})]})]})}function ja({storedJobs:e,onLoad:t,onDelete:a}){return e.length?n.jsxs("section",{className:"review-archive","aria-label":"历史定制",children:[n.jsxs("header",{children:[n.jsx("strong",{children:"历史定制"}),n.jsxs("small",{children:[e.length," 个版本 · 全部仅本机"]})]}),n.jsx("ul",{children:e.map(([s,o])=>n.jsxs("li",{children:[n.jsxs("span",{className:"meta",children:[n.jsx("strong",{children:s.replace(/^tailor_/,"")}),n.jsxs("small",{children:["保存于 ",ce(o.savedAt)]})]}),n.jsxs("span",{className:"row-actions",children:[n.jsxs("button",{type:"button",onClick:()=>t(s),children:[n.jsx(Se,{size:13})," 载入"]}),n.jsxs("button",{type:"button",className:"danger",onClick:()=>a(s),children:[n.jsx(we,{size:13})," 删除"]})]})]},s))})]}):null}function $a(e){return ut({jobKey:"",company:e.company||"未填公司",position:e.position||"未填岗位",city:e.city,jobType:e.jobType,deadline:e.deadline,summary:e.summary,responsibilities:e.responsibilities||[],requirements:e.requirements||[],rawExcerpt:e.rawExcerpt,sourceUrl:e.sourceUrl})}function ct(e){return e.split(/\r?\n/).map(t=>t.replace(/^[\s\-•·●]+/,"").trim()).filter(Boolean)}function ka(e){if(e)try{return new URL(e).hostname}catch{return}}function Sa(e){const t=a=>{const s=JSON.parse(a);if(s.context)return{jobKey:s.jobKey||s.context.jobKey||"",context:s.context};if(typeof s.position=="string"){const o=s;return{jobKey:o.jobKey||"",context:o}}};try{const a=t(decodeURIComponent(e));if(a)return a}catch{}try{const a=Ea(decodeURIComponent(e)),s=t(a);if(s)return s}catch{}throw new Error("岗位上下文解析失败")}function Ea(e){const t=atob(e),a=new Uint8Array(t.length);for(let s=0;s<t.length;s+=1)a[s]=t.charCodeAt(s);return new TextDecoder().decode(a)}function Pa(e){const t=JSON.stringify(e),a=new TextEncoder().encode(t);let s="";for(let o=0;o<a.length;o+=32768)s+=String.fromCharCode.apply(null,Array.from(a.subarray(o,Math.min(o+32768,a.length))));return encodeURIComponent(btoa(s))}function gt(e){return e<1024?`${e} B`:e<1024*1024?`${(e/1024).toFixed(1)} KB`:`${(e/(1024*1024)).toFixed(2)} MB`}function ce(e){if(!e)return"刚刚";const t=new Date(e).getTime(),a=Date.now(),s=Math.round((a-t)/1e3);return s<60?"刚刚":s<3600?`${Math.round(s/60)} 分钟前`:s<86400?`${Math.round(s/3600)} 小时前`:new Date(e).toLocaleString("zh-CN")}function Na(e){const t=new Uint8Array(e),a=32768;let s="";for(let o=0;o<t.length;o+=a)s+=String.fromCharCode.apply(null,Array.from(t.subarray(o,Math.min(o+a,t.length))));return btoa(s)}function ye(e){const t=atob(e),a=new Uint8Array(t.length);for(let s=0;s<t.length;s+=1)a[s]=t.charCodeAt(s);return a}Ht.createRoot(document.getElementById("root")).render(n.jsx(Jt.StrictMode,{children:n.jsx(la,{})}));
